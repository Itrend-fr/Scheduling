<?

/*

$search = '/embed/';

$html='https://www.youtube.com/embed/p6NSlonIuT8?rel=0';

   if (preg_match($search, $html, $matches)) { // Yes

       #$videoID = $matches[1];

	   $links=explode($search,$html);

	   $link=explode('?',$links[1]);

		 echo ($link[0]);

       // Recreate your embed iframe here ...

   }

   exit;

*/

require 'includes/config.php';
require 'includes/functions.php';



session_start();



extract($_REQUEST);

$_SESSION['lang'] = 'en';



// Logging out

if (isset($_GET['logout']) && $_GET['logout'] == 'true') {

session_destroy();

session_start();

header("Location: ".BURL."admin/login.php");

}



#echo BURL; exit;

// If no Session bye bye!

if (!$_SESSION[$sessobject_name]) {

	header("Location: ".BURL."admin/login.php");



//header("Location: login.php");

}



// if section does not exist or privileges does not match or page is not active go to dashboard



if (isset($_GET['goto']) && $_GET['goto'] && $_SESSION['admin_role']!='SuperAdmin' ) {

	$tblrole =getfield("bo_interface","role"," where url='".Q($_GET['goto'])."'");

	if (!is_numeric(getfield("bo_interface","id"," where url='".Q($_GET['goto'])."' and active='Yes'")) || ($tblrole=='SuperAdmin' || ($tblrole=='Admin' && $_SESSION['admin_role']=='User'))) {

		//header("Location: index.php");

		header("Location: ".BURL."admin/index.php");



	}

}



?><!DOCTYPE html>

<html lang="en">

  <head>

    <meta charset="utf-8">

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">

    <meta name="author" content="">

    <link rel="icon" href="<?=$site_favicon?>">



    <title><?=$bo_sitename?> backend</title>



    

	 <!-- Bootstrap core JavaScript

    ================================================== -->

    <!-- Placed at the end of the document so the pages load faster -->

    <script src="js/jquery.min.js"></script>

    <script src="js/bootstrap.min.js"></script>

    <script src="js/docs.min.js"></script>

    <script src="js/moment.js"></script>    

   	<script src="js/bootstrap-datetimepicker.js"></script>

    <script src="js/bootstrap-table.min.js"></script>

	<script src="js/jasny-bootstrap.min.js"></script>

	<script src="js/bootstrap-table-cookie.js"></script>   

    <script src="js/tableExport.min.js"></script>  

    <script src="js/bootstrap-table-export.js"></script>  

    <script src="js/bootstrap-editable.js"></script> 

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->

    <script src="js/ie10-viewport-bug-workaround.js"></script>

    <script src="js/select2.min.js"></script>



    <!-- Bootstrap core CSS -->

    <link href="css/bootstrap.min.css" rel="stylesheet">



    <!-- Custom styles for this template -->

    <link href="css/signin.css" rel="stylesheet">

	<link href="css/dashboard.css" rel="stylesheet">

    <link href="css/sticky-footer.css" rel="stylesheet">

    <link href="css/bootstrap-datetimepicker.css" rel="stylesheet">

	<link href="css/font-awesome.min.css" rel="stylesheet"> 

    <link href="css/bootstrap-table.min.css" rel="stylesheet">  

	<link href="css/jasny-bootstrap.min.css" rel="stylesheet" >

	<link href="css/bootstrap-editable.css" rel="stylesheet" >

  <link href="css/select2.min.css" rel="stylesheet" >

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->

    <!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js"></script><![endif]-->

    <script src="js/ie-emulation-modes-warning.js"></script>




    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!--[if lt IE 9]>

      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->

    

    <? include 'includes/style.php';?>



    <script language="javascript">

	

	// set editable to inline

	$.fn.editable.defaults.mode = 'inline';

	

	$(document).ready(function(){

		setInterval(function() {

			(new Image()).src="sstart.php"

		}, 1000 * 60);

		

		jQuery('.back-to-top').hide(0);

	    var offset = 250;

		var duration = 300;

		jQuery(window).scroll(function() {

			if (jQuery(this).scrollTop() > offset) {

				jQuery('.back-to-top').fadeIn(duration);

			} else {

				jQuery('.back-to-top').fadeOut(duration);

			}

		});

	

		jQuery('.back-to-top').click(function(event) {

			event.preventDefault();

			jQuery('html, body').animate({scrollTop: 0}, duration);

			return false;

		})

	});

</script>

  </head>

<body style="padding-top:0;">

 <div class="container-fluid md_hide" style="background:#333;">

        <div class="navbar-header">

          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">

            <span class="sr-only">Toggle navigation</span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>

          </button>

          <a class="navbar-brand" href="index.php"><?=$_SESSION['bo_sitename']?></a>

        </div>

        <div class="navbar-collapse collapse">

          <ul class="nav navbar-nav navbar-right">

       

          

          <? $roleqry=''; 

		  if ($_SESSION['admin_role']!='Admin' && $_SESSION['admin_role']!='SuperAdmin' &&  $_SESSION['admin_role']!='Owner' ){ 

		  	$roleqry.=" and role='User' " ; 

			} else if ($_SESSION['admin_role']=='Owner'){ 

		  	$roleqry.=" and (role='Owner' or role='User') " ; 

			} else if ($_SESSION['admin_role']=='Admin') { 

			$roleqry.="  and (role='Admin' or role='Owner' or role='User')" ; 

			} 

		  $cn = mysqli_query($link_connect,"select * from bo_interface where active='Yes' and boid='0' ".$roleqry." order by pos,name") or die(mysqli_error($link_connect));

		 while ($rs=mysqli_fetch_object($cn)) {

			 $cni = mysqli_query($link_connect,"select * from bo_interface where active='Yes' and boid='".$rs->id."' ".$roleqry." order by pos,name");

			 if (mysqli_num_rows($cni)) {?>

				 <li class="dropdown">

              <a href="#" class="dropdown-toggle" data-toggle="dropdown" ><?=$rs->name?><span class="caret"></span></a>

              <ul class="dropdown-menu" role="menu">

                <? 

		 while ($rsi=mysqli_fetch_object($cni)) {?>

         	<li><a href="<? if ($rsi->standalone=='Yes') { echo $rsi->url; } else {?>index.php?goto=<?=$rsi->url?><? } ?>"><?=$rsi->name?></a></li>

           

         <? }?>

               

              </ul>

            </li>

			<? } else {?>

				<li><a href="<? if ($rs->standalone=='Yes') { echo $rs->url; } else {?>index.php?goto=<?=$rs->url?><? } ?>"><?=$rs->name?></a></li> 

			 <? }

		 }

			 ?>

	

       

          

          </ul>

    

          

          

        </div>

      </div>

    </div>

  <div class="container-fluid">



    <div class="container">

      <div class="row">

        <div class="col-sm-3 col-md-2 sidebar">

         <ul class="nav nav-sidebar"><li class="sbtitle2">beinvenue <?=$_SESSION['admin_name']?>!</li></ul>

        

         <? 

		 $roleqry=''; 

		  if ($_SESSION['admin_role']!='Admin' && $_SESSION['admin_role']!='SuperAdmin'){ 

		  	$roleqry.=" and role='User' " ; 

			} else if ($_SESSION['admin_role']=='Admin') { 

			$roleqry.="  and (role='Admin' or role='User')" ; 

			} 

		 $cn = mysqli_query($link_connect,"select * from bo_interface where active='Yes' and boid='0' ".$roleqry." order by pos,name");

		 while ($rs=mysqli_fetch_object($cn)) {?>

			  <ul class="nav nav-sidebar">

           <? $linktitle=getfield("bo_interface","name"," where active='Yes' and boid='".$rs->id."' ".$roleqry." ");?>

           <? #if($linktitle && $rs->id!=15 && $rs->id!=2){?>

           <? if (!$rs->url && $linktitle) {?>

           <li class="sbtitle" ><?=$rs->name?></li>

		   <? } elseif ($rs->url) {?>

           <li <? if (((!isset($_GET['goto']) || !$_GET['goto']) && $rs->url=='index.php') || (isset($_GET['goto']) && $rs->url==$_GET['goto'])) {?>class="active"<? }?>>

           <a href="<? if ($rs->standalone=='Yes') { echo $rs->url; } else {?>index.php?goto=<?=$rs->url?><? } ?>" ><?=$rs->name?></a></li>

		   <? }?>

             <? $cni = mysqli_query($link_connect,"select * from bo_interface where active='Yes' and boid='".$rs->id."' ".$roleqry." order by pos,name");

		 while ($rsi=mysqli_fetch_object($cni)) {?>

         	<li <? if (isset($_GET['goto']) && $rsi->url==$_GET['goto']) {?>class="active"<? }?>><a href="<? if ($rsi->standalone=='Yes') { echo $rsi->url; } else {?>index.php?goto=<?=$rsi->url?><? } ?>"><?=$rsi->name?></a></li>

         <? }

		   #}?>

            </ul>

		<? } ?>

        </div>

        <div class="col-sm-12 col-md-10 col-md-offset-2 main">

        <? if (!isset($_GET['goto']) || !$_GET['goto']) {?>

         

		<? include 'pages/dashboard.php' ?>



<? } else  {  

$cn=mysqli_query($link_connect,"select * from bo_interface where url='".Q($_GET['goto'])."'");

if (mysqli_num_rows($cn)) {

	$rs=mysqli_fetch_object($cn);

	if($rs->id=='20'){

	?><h1 class="page-header"><?=ucwords($_REQUEST['page_title'])?></h1><? }else{?>

    <h1 class="page-header"><?=$rs->name?></h1>

	<? }

include 'pages/'.$rs->incfile; 

}



}?>

<a href="#" class="back-to-top noprint" style="display: inline">

<i class="fa fa-arrow-circle-up"></i>

</a>

      </div>

    </div>

    

    </div> <!-- /container -->



</div>



  </body> 

</html>





