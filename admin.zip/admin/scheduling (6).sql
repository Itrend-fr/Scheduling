-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 12, 2023 at 09:51 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scheduling`
--

-- --------------------------------------------------------

--
-- Table structure for table `agenda_consultation`
--

CREATE TABLE `agenda_consultation` (
  `appointmentid` int(10) UNSIGNED NOT NULL,
  `agendaid` int(10) UNSIGNED DEFAULT NULL,
  `consultationid` int(10) UNSIGNED NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `agenda_consultation`
--

INSERT INTO `agenda_consultation` (`appointmentid`, `agendaid`, `consultationid`, `starttime`, `endtime`, `status`) VALUES
(1, 2, 1, '02:22:00', '02:30:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `appointmentstatus`
--

CREATE TABLE `appointmentstatus` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointmentstatus`
--

INSERT INTO `appointmentstatus` (`id`, `label`, `description`) VALUES
(2, 'General', 'General');

-- --------------------------------------------------------

--
-- Table structure for table `bo_admins`
--

CREATE TABLE `bo_admins` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('SuperAdmin','Admin','User') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'User',
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bo_admins`
--

INSERT INTO `bo_admins` (`id`, `name`, `email`, `password`, `type`, `token`) VALUES
(1, 'Super Admin', 'hashjhas@hotmail.com', '25d55ad283aa400af464c76d713c07ad', 'SuperAdmin', '19460874286543f8c7547094.72065512');

-- --------------------------------------------------------

--
-- Table structure for table `bo_interface`
--

CREATE TABLE `bo_interface` (
  `id` int(10) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `incfile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `main_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `boid` int(10) NOT NULL,
  `role` enum('SuperAdmin','Admin','User') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'User',
  `standalone` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'No',
  `pos` int(11) NOT NULL,
  `active` enum('Yes','No') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Yes'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bo_interface`
--

INSERT INTO `bo_interface` (`id`, `name`, `url`, `incfile`, `main_table`, `boid`, `role`, `standalone`, `pos`, `active`) VALUES
(2, 'Logout', 'index.php?logout=true', '', '', 0, 'User', 'Yes', 5, 'Yes'),
(118, 'Gérer l\'emplacement et les services', 'gerer-emplacement-services', 'serviceslocation.php', 'location_service', 4, 'User', 'No', 14, 'Yes'),
(4, 'Contenu du site', '', '', '', 0, 'User', 'No', 2, 'Yes'),
(6, 'Admin Accounts', 'bomanagers', 'sitemanagers.php', 'bo_admins', 4, 'Admin', 'No', 11, 'Yes'),
(119, 'Gérer l\'ordre du jour', 'gerer-lorder-du-jour', 'tagenda.php', 'tagenda', 4, 'User', 'No', 14, 'Yes'),
(120, 'Entity & Department', 'department-entity', 'tentitydepartment.php', 'entity_department', 4, 'User', 'No', 14, 'Yes'),
(15, 'Tableau de bord', 'index.php', 'dashboard.php', '', 0, 'User', 'Yes', 1, 'Yes'),
(20, 'Paragraphs', 'para', 'para.php', '', 9999, 'User', 'No', 1, 'Yes'),
(124, 'Gérer le genre', 'gerer-genre', 'tgender.php', 'tgender', 4, 'User', 'No', 16, 'Yes'),
(44, 'Autorisations', 'boprivileges', 'boprivileges.php', 'bo_interface', 4, 'SuperAdmin', 'No', 9, 'Yes'),
(35, 'Vues d\'administration', 'vues-administration', 'bointerface.php', 'bo_interface', 4, 'SuperAdmin', 'No', 10, 'Yes'),
(109, 'Gérer les entités', 'gerer-entites', 'tentities.php', 'tentity', 4, 'User', 'No', 9, 'Yes'),
(110, 'Gérer les services', 'gerer-services', 'tservices.php', 'tservice', 4, 'User', 'No', 9, 'Yes'),
(52, 'Photo/Video Gallery', 'gallery', 'gallery.php', '', 9999, 'User', 'No', 1, 'Yes'),
(53, 'File Manager', 'file', 'file.php', '', 9999, 'User', 'No', 1, 'Yes'),
(106, 'Type d\'utilisateur', 'utilisateur-type', 'tusertype.php', 'tusertype', 4, 'User', 'No', 6, 'Yes'),
(83, 'Package Programs', 'programs', 'programs.php', 'fe_package_program', 9999, 'User', 'No', 5, 'Yes'),
(121, 'Gerer appointment', 'gerer-appointment', 'appointmentstatus.php', 'appointmentstatus', 4, 'User', 'No', 15, 'Yes'),
(117, 'Gérer les services et les entités', 'gerer-services-entites', 'tservicesentity.php', 'service_entity', 4, 'User', 'No', 14, 'Yes'),
(113, 'Gérer le centre', 'gerer-center', 'tcenter.php', 'tcenter', 4, 'User', 'No', 11, 'Yes'),
(114, 'Gérer les consultations', 'gerer-consultations', 'tconsultation.php', 'tconsultation', 4, 'User', 'No', 12, 'Yes'),
(115, 'Gérer les pays', 'gerer-pays', 'tcountries.php', 'tcountry', 4, 'User', 'No', 13, 'Yes'),
(116, 'Gérer les langues', 'gerer-langues', 'tlanguages.php', 'tlanguage', 4, 'User', 'No', 13, 'Yes'),
(111, 'Gérer les emplacements', 'gerer-emplacements', 'tlocations.php', 'tlocation', 4, 'User', 'No', 10, 'Yes'),
(112, 'Gérer les départements', 'gerer-departments', 'tdepartments.php', 'tdepartment', 4, 'User', 'No', 11, 'Yes'),
(108, 'Gérer les patients', 'gerer-patients', 'tpatients.php', 'tpatient', 4, 'User', 'No', 8, 'Yes'),
(107, 'Utilisateur', 'utilisateur', 'tuser.php', 'tuser', 4, 'User', 'No', 7, 'Yes'),
(122, 'Agenda et Consultation', 'agenda-consultation', 'agenda_consultation.php', 'agenda_consultation', 4, 'User', 'No', 15, 'Yes'),
(123, 'Labels', 'labels', 'tlabels.php', 'tlabels', 4, 'User', 'No', 16, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `entity_department`
--

CREATE TABLE `entity_department` (
  `entityid` int(10) UNSIGNED NOT NULL,
  `departmentid` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `entity_department`
--

INSERT INTO `entity_department` (`entityid`, `departmentid`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `location_service`
--

CREATE TABLE `location_service` (
  `locationid` smallint(5) UNSIGNED NOT NULL,
  `serviceid` int(10) UNSIGNED NOT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location_service`
--

INSERT INTO `location_service` (`locationid`, `serviceid`, `startdate`, `enddate`) VALUES
(1, 1, '2023-11-09', '2023-11-09');

-- --------------------------------------------------------

--
-- Table structure for table `service_entity`
--

CREATE TABLE `service_entity` (
  `serviceid` int(10) UNSIGNED NOT NULL,
  `entityid` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service_entity`
--

INSERT INTO `service_entity` (`serviceid`, `entityid`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tagenda`
--

CREATE TABLE `tagenda` (
  `aid` int(10) UNSIGNED NOT NULL,
  `serviceid` int(10) UNSIGNED NOT NULL,
  `locationid` smallint(5) UNSIGNED NOT NULL,
  `date` date DEFAULT NULL,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tagenda`
--

INSERT INTO `tagenda` (`aid`, `serviceid`, `locationid`, `date`, `starttime`, `endtime`) VALUES
(2, 1, 1, '2023-11-11', '02:20:00', '02:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `tcenter`
--

CREATE TABLE `tcenter` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `lemail` varchar(50) DEFAULT NULL,
  `ltel` varchar(30) DEFAULT NULL,
  `laddr` varchar(100) DEFAULT NULL,
  `lpostcode` varchar(7) DEFAULT NULL,
  `lcity` varchar(30) DEFAULT NULL,
  `lcountry` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tcenter`
--

INSERT INTO `tcenter` (`id`, `label`, `description`, `lemail`, `ltel`, `laddr`, `lpostcode`, `lcity`, `lcountry`) VALUES
(1, 'Charles de Gaulle', '', '', '', 'Paris, rue Charles de Gaulle', '', 'Paris', 'it');

-- --------------------------------------------------------

--
-- Table structure for table `tconsultation`
--

CREATE TABLE `tconsultation` (
  `id` int(10) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `duration` tinyint(3) UNSIGNED NOT NULL,
  `serviceid` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tconsultation`
--

INSERT INTO `tconsultation` (`id`, `label`, `description`, `duration`, `serviceid`) VALUES
(1, 'Revérifier', 'Rev&eacute;rifier', 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tcountry`
--

CREATE TABLE `tcountry` (
  `id` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `label` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tcountry`
--

INSERT INTO `tcountry` (`id`, `label`) VALUES
('es', 'Spain'),
('fr', 'France'),
('it', 'Italy'),
('ru', 'Russia'),
('us', 'United States');

-- --------------------------------------------------------

--
-- Table structure for table `tdepartment`
--

CREATE TABLE `tdepartment` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `centerid` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tdepartment`
--

INSERT INTO `tdepartment` (`id`, `label`, `description`, `centerid`) VALUES
(1, 'Santé', 'Sant&eacute; g&eacute;n&eacute;rale', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tentity`
--

CREATE TABLE `tentity` (
  `eid` int(10) UNSIGNED NOT NULL,
  `efirstname` varbinary(200) DEFAULT NULL,
  `elastname` varbinary(200) DEFAULT NULL,
  `egender` tinyint(3) UNSIGNED DEFAULT NULL,
  `eemail` varbinary(300) DEFAULT NULL,
  `etel` varbinary(200) DEFAULT NULL,
  `eaddr` varchar(100) DEFAULT NULL,
  `epostcode` varchar(7) DEFAULT NULL,
  `ecity` varchar(30) DEFAULT NULL,
  `ecountry` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `gradyear` smallint(5) UNSIGNED DEFAULT NULL,
  `practice` tinyint(3) UNSIGNED DEFAULT NULL,
  `specialty` tinyint(3) UNSIGNED DEFAULT NULL,
  `lang` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `detail` varchar(1000) DEFAULT NULL,
  `edatep` datetime NOT NULL,
  `edatec` datetime NOT NULL,
  `edatem` datetime NOT NULL,
  `euidm` int(10) UNSIGNED NOT NULL,
  `luid` int(10) UNSIGNED DEFAULT NULL,
  `meges_entity_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tentity`
--

INSERT INTO `tentity` (`eid`, `efirstname`, `elastname`, `egender`, `eemail`, `etel`, `eaddr`, `epostcode`, `ecity`, `ecountry`, `gradyear`, `practice`, `specialty`, `lang`, `detail`, `edatep`, `edatec`, `edatem`, `euidm`, `luid`, `meges_entity_id`) VALUES
(1, 0x446f727279, 0x536d697468, 4, 0x736d69746840656d61696c2e636f6d, '', '', '', '', 'es', 2018, 0, 0, 'en', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tgender`
--

CREATE TABLE `tgender` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `text_en` varchar(20) NOT NULL,
  `text_fr` varchar(20) DEFAULT NULL,
  `text_ar` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tgender`
--

INSERT INTO `tgender` (`id`, `text_en`, `text_fr`, `text_ar`) VALUES
(4, 'M', 'M', 'M'),
(5, 'F', 'F', 'F');

-- --------------------------------------------------------

--
-- Table structure for table `tlabels`
--

CREATE TABLE `tlabels` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `text_en` text NOT NULL,
  `text_fr` text DEFAULT NULL,
  `text_ar` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tlanguage`
--

CREATE TABLE `tlanguage` (
  `id` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `label` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tlanguage`
--

INSERT INTO `tlanguage` (`id`, `label`) VALUES
('en', 'English'),
('fr', 'Français');

-- --------------------------------------------------------

--
-- Table structure for table `tlocation`
--

CREATE TABLE `tlocation` (
  `lid` smallint(5) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `lemail` varchar(50) DEFAULT NULL,
  `ltel` varchar(30) DEFAULT NULL,
  `laddr` varchar(100) DEFAULT NULL,
  `lpostcode` varchar(7) DEFAULT NULL,
  `lcity` varchar(30) DEFAULT NULL,
  `lcountry` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tlocation`
--

INSERT INTO `tlocation` (`lid`, `label`, `description`, `lemail`, `ltel`, `laddr`, `lpostcode`, `lcity`, `lcountry`) VALUES
(1, 'Paris', 'Chons&eacute;liser', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tpatient`
--

CREATE TABLE `tpatient` (
  `pid` int(10) UNSIGNED NOT NULL,
  `pfirstname` varbinary(200) DEFAULT NULL,
  `plastname` varbinary(200) DEFAULT NULL,
  `gender` tinyint(3) UNSIGNED DEFAULT NULL,
  `pemail` varbinary(300) DEFAULT NULL,
  `ptel` varbinary(200) DEFAULT NULL,
  `paddr` varchar(100) DEFAULT NULL,
  `ppostcode` varchar(7) DEFAULT NULL,
  `pcity` varchar(30) DEFAULT NULL,
  `pcountry` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `dateofbirth` date DEFAULT NULL,
  `lang` char(2) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `contactinfo` varchar(1000) DEFAULT NULL,
  `pdatec` datetime NOT NULL,
  `pdatem` datetime NOT NULL,
  `puidm` int(10) UNSIGNED NOT NULL,
  `luid` int(10) UNSIGNED DEFAULT NULL,
  `meges_patient_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tpatient`
--

INSERT INTO `tpatient` (`pid`, `pfirstname`, `plastname`, `gender`, `pemail`, `ptel`, `paddr`, `ppostcode`, `pcity`, `pcountry`, `dateofbirth`, `lang`, `contactinfo`, `pdatec`, `pdatem`, `puidm`, `luid`, `meges_patient_id`) VALUES
(1, 0x4d61726f756e, 0x4265726b61636869, 4, 0x6d61726f756e62656b6163686940686f746d61696c2e636f6d, '', '', '', '', 'fr', '0000-00-00', 'en', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tservice`
--

CREATE TABLE `tservice` (
  `sid` int(10) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `mainmember` int(10) UNSIGNED NOT NULL,
  `departmentid` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tservice`
--

INSERT INTO `tservice` (`sid`, `label`, `description`, `mainmember`, `departmentid`) VALUES
(1, 'Check', '', 1, NULL),
(2, 'Revision', 'Revision', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tuser`
--

CREATE TABLE `tuser` (
  `uid` int(10) UNSIGNED NOT NULL,
  `usertypeid` tinyint(3) UNSIGNED DEFAULT NULL,
  `uactive` tinyint(3) UNSIGNED DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `pwd` varbinary(150) DEFAULT NULL,
  `udatep` datetime NOT NULL,
  `udatec` datetime NOT NULL,
  `udatem` datetime NOT NULL,
  `uuidm` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tuser`
--

INSERT INTO `tuser` (`uid`, `usertypeid`, `uactive`, `login`, `pwd`, `udatep`, `udatec`, `udatem`, `uuidm`) VALUES
(1, 2, NULL, 'hashjhas', 0x3235643535616432383361613430306166343634633736643731336330376164, '0000-00-00 00:00:00', '2023-11-08 21:11:15', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tusertype`
--

CREATE TABLE `tusertype` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `rights` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tusertype`
--

INSERT INTO `tusertype` (`id`, `label`, `description`, `rights`) VALUES
(1, 'Patient', '', ''),
(2, 'Doctor', '', ''),
(3, 'Assistance', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda_consultation`
--
ALTER TABLE `agenda_consultation`
  ADD PRIMARY KEY (`appointmentid`),
  ADD KEY `acfk1_idx` (`status`);

--
-- Indexes for table `appointmentstatus`
--
ALTER TABLE `appointmentstatus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bo_admins`
--
ALTER TABLE `bo_admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bo_interface`
--
ALTER TABLE `bo_interface`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entity_department`
--
ALTER TABLE `entity_department`
  ADD KEY `edfk1_idx` (`entityid`),
  ADD KEY `edfk2_idx` (`departmentid`);

--
-- Indexes for table `service_entity`
--
ALTER TABLE `service_entity`
  ADD KEY `sefk1_idx` (`serviceid`),
  ADD KEY `sefk2_idx` (`entityid`);

--
-- Indexes for table `tagenda`
--
ALTER TABLE `tagenda`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `tcenter`
--
ALTER TABLE `tcenter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tconsultation`
--
ALTER TABLE `tconsultation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cfk1_idx` (`serviceid`);

--
-- Indexes for table `tcountry`
--
ALTER TABLE `tcountry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tdepartment`
--
ALTER TABLE `tdepartment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dfk1_idx` (`centerid`);

--
-- Indexes for table `tentity`
--
ALTER TABLE `tentity`
  ADD PRIMARY KEY (`eid`),
  ADD KEY `efk1_idx` (`luid`);

--
-- Indexes for table `tgender`
--
ALTER TABLE `tgender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tlabels`
--
ALTER TABLE `tlabels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tlanguage`
--
ALTER TABLE `tlanguage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tlocation`
--
ALTER TABLE `tlocation`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `tpatient`
--
ALTER TABLE `tpatient`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `pfk1_idx` (`luid`);

--
-- Indexes for table `tservice`
--
ALTER TABLE `tservice`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `sfk1_idx` (`mainmember`),
  ADD KEY `sfk2_idx` (`departmentid`);

--
-- Indexes for table `tuser`
--
ALTER TABLE `tuser`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `ufk1_idx` (`usertypeid`);

--
-- Indexes for table `tusertype`
--
ALTER TABLE `tusertype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agenda_consultation`
--
ALTER TABLE `agenda_consultation`
  MODIFY `appointmentid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointmentstatus`
--
ALTER TABLE `appointmentstatus`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bo_admins`
--
ALTER TABLE `bo_admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `bo_interface`
--
ALTER TABLE `bo_interface`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `tagenda`
--
ALTER TABLE `tagenda`
  MODIFY `aid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tcenter`
--
ALTER TABLE `tcenter`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tconsultation`
--
ALTER TABLE `tconsultation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tdepartment`
--
ALTER TABLE `tdepartment`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tentity`
--
ALTER TABLE `tentity`
  MODIFY `eid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tgender`
--
ALTER TABLE `tgender`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tlocation`
--
ALTER TABLE `tlocation`
  MODIFY `lid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tpatient`
--
ALTER TABLE `tpatient`
  MODIFY `pid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tservice`
--
ALTER TABLE `tservice`
  MODIFY `sid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tuser`
--
ALTER TABLE `tuser`
  MODIFY `uid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agenda_consultation`
--
ALTER TABLE `agenda_consultation`
  ADD CONSTRAINT `acfk1` FOREIGN KEY (`status`) REFERENCES `appointmentstatus` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `entity_department`
--
ALTER TABLE `entity_department`
  ADD CONSTRAINT `edfk1` FOREIGN KEY (`entityid`) REFERENCES `tentity` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `edfk2` FOREIGN KEY (`departmentid`) REFERENCES `tdepartment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `service_entity`
--
ALTER TABLE `service_entity`
  ADD CONSTRAINT `sefk1` FOREIGN KEY (`serviceid`) REFERENCES `tservice` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sefk2` FOREIGN KEY (`entityid`) REFERENCES `tentity` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tconsultation`
--
ALTER TABLE `tconsultation`
  ADD CONSTRAINT `cfk1` FOREIGN KEY (`serviceid`) REFERENCES `tservice` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tdepartment`
--
ALTER TABLE `tdepartment`
  ADD CONSTRAINT `dfk1` FOREIGN KEY (`centerid`) REFERENCES `tcenter` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tentity`
--
ALTER TABLE `tentity`
  ADD CONSTRAINT `efk1` FOREIGN KEY (`luid`) REFERENCES `tuser` (`uid`) ON UPDATE CASCADE;

--
-- Constraints for table `tpatient`
--
ALTER TABLE `tpatient`
  ADD CONSTRAINT `pfk1` FOREIGN KEY (`luid`) REFERENCES `tuser` (`uid`) ON UPDATE CASCADE;

--
-- Constraints for table `tservice`
--
ALTER TABLE `tservice`
  ADD CONSTRAINT `sfk1` FOREIGN KEY (`mainmember`) REFERENCES `tentity` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sfk2` FOREIGN KEY (`departmentid`) REFERENCES `tdepartment` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tuser`
--
ALTER TABLE `tuser`
  ADD CONSTRAINT `ufk1` FOREIGN KEY (`usertypeid`) REFERENCES `tusertype` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
