<?
require 'includes/config.php';
require 'includes/functions.php';

session_start();

// Setting Language of BO
$_SESSION['lang']= 'en';

if (isset($_SESSION[$sessobject_name]) && $_SESSION[$sessobject_name]) { header("Location: index.php"); } ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?=$site_favicon?>">

    <title><?=$bo_sitename?> Admin</title>

    
	 <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
   
   	<script type="text/javascript" src="js/login.js"></script>
    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
	<link href="css/sticky-footer.css" rel="stylesheet">
   
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <? include 'includes/style.php';?>
  </head>

  <body>
    <div class="container">
    <? if (!isset($_GET['d']) || $_GET['d']!=='reset') {?>
      <div id="loginwaiting" style="display: none; text-align:center; padding-top:20px;" ><img src="images/loader.gif" title="Loader" alt="Loader" align="absmiddle" /> Logging in ... Please wait </div>
<form action="" method="post" name="loginform" id="loginform"  class="form-signin" role="form">
		<div align="center" style="padding-bottom:10px"><img src="images/<?=$site_logo?>" class="img-responsive" /></div>
        <div id="loginmessage" style="display: none;" role="alert"></div>
		
        <h2 class="form-signin-heading">Sign in</h2>
        <input name="email" id="email" type="email" class="form-control" placeholder="Email address" required autofocus>
        <input name="password" type="password" id="password" class="form-control" placeholder="Password" required>
        
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="loginsubmit" id="loginsubmit">Sign in</button>
        <p><button class="btn btn-sm btn-link" id="fpass">Forgot Password</button></p>
      </form>
	
    <script language="javascript">
$(document).ready(function() {
$('#fpass').click(function() {
$('#forgotpass').show();
$('#loginmessage').hide();
return false;
});
$('#fpass_close').click(function() {
$('#forgotpass').hide();
$('#fpmessage').hide();
return false;
});
});
</script>
<script type="text/javascript" src="js/fpass.js"></script>
<div style="display:none" id="forgotpass">

<div id="fpwaiting" style="display: none;text-align:center;">
<img src="images/loader.gif" title="Loader" alt="Loader" align="absmiddle" /> Please wait
</div>
<form name="fpassf" id="fpassf" method="post" action="" class="form-signin" role="form">
<div id="fpmessage" style="display: none;" role="alert"></div>
 <input name="fpemail" id="fpemail" type="email" class="form-control" placeholder="Enter your E-mail Address" required autofocus>
 
 <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" id="submit">Reset Password</button>
 <p><button class="btn btn-sm btn-link" id="fpass_close">Close</button></p>
</form>
<? } else {

$rsid=$_REQUEST['i'];
$rstoken=$_REQUEST['t'];
$rsreset=$_REQUEST['d'];

$cn=mysqli_query($link_connect,"select * from bo_admins where token='".Q($rstoken)."' and id='".Q($rsid)."'");
	?>

<div style="max-width:330px; margin: 0 auto;">
<div style="padding-bottom:10px"><img src="images/<?=$site_logo?>" class="img-responsive" /></div>
<div id="rsmessage" style="display: none;" role="alert"></div>
<div id="rswaiting" style="display: none; text-align:center; padding-top:20px;" ><img src="images/loader.gif" title="Loader" alt="Loader" align="absmiddle" /> Validating in ... Please wait </div>
<form action="" method="post" name="resetform" id="resetform"   role="form">

<h2 class="form-signin-heading">Reset Password</h2>
<? if (mysqli_num_rows($cn)) { 
$rs=mysqli_fetch_object($cn)?>
<script type="text/javascript" src="js/reset.js"></script>
<div id="rsmessage" style="display: none;" role="alert"></div>
<div class="form-group">
    <label for="email">Email Address: </label>
    <?=$rs->email?>
</div>
<div class="form-group">
<label for="email">Password: <span class="text-danger">Minimum 8 Characters</span></label>
        <input name="password" type="password" id="password" class="form-control" placeholder="Password">
        </div>
<div class="form-group">

        <input name="retypepassword" type="password" id="retypepassword" class="form-control" placeholder="Retype Password" >
        </div>        
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="resetsubmit" id="resetsubmit"> Reset</button>
        <input type="hidden" name="i" id="i" value="<?=$rsid?>">
        <input type="hidden" name="t" id="t" value="<?=$rstoken?>">
        <input type="hidden" name="d" id="d" value="<?=$rsreset?>">
        </form>
        <? } else {?>
        <div class="alert-danger alert" role="alert"> Reset already completed or Link is not Valid. <a href="login.php">Click Here</a> to Reset your Password Again.</div>
        <? } ?>
</div>
<? }?>
    </div>    
    </div> <!-- /container -->



  </body>
</html>
