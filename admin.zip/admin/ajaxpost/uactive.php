<? 
require '../../includes/config.php';
require '../../includes/functions.php';

session_start();


if ($_SESSION[$sessobject_name]) {
	
	if ($_POST['value']) {
		$cn=mysqli_query($link,"select ".Q($_POST['name'])." from ".Q($_POST['table'])." where ".Q($_POST['primary_field'])."='".Q($_POST['pk'])."'");
		if (mysqli_num_rows($cn)) {
			$ndate = date('Y-m-d',strtotime('now'));
			//echo $ndate; exit(0);
			mysqli_query($link,"update ".Q($_POST['table'])." set ".Q($_POST['name'])."='".Q($_POST['value'])."', date_activated='".Q($ndate)."' where ".Q($_POST['primary_field'])."='".Q($_POST['pk'])."'");

		} else {
			header('HTTP 400 Bad Request', true, 400);
			echo 'Record Not Found.';
		}
	} else {
			header('HTTP 400 Bad Request', true, 400);
			echo 'Please Use Numeric Values only.';
	}

}
?>