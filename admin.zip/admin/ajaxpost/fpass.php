<?
require '../includes/config.php';
require '../includes/class.phpmailer.php';
require '../includes/functions.php';

session_start();

if (empty($_POST['fpemail'])) {
$return['error'] = true;
$return['msg'] = 'You did not enter your Email Address.';

} else if (isemail($_POST['fpemail']) =='0') {
$return['error'] = true;
$return['msg'] = 'Please enter a Valid Email Address.';

} else {
$themail = $_POST['fpemail'];
$conn = mysqli_query($link_connect,"SELECT id,name,password,email FROM bo_admins where email = '".Q($themail)."' "); 
$rows = mysqli_num_rows($conn);
if ($rows == '0') {
$return['error'] = true;
$return['msg'] = 'The Email Address '.$_POST['fpemail'].' is not associated with an Account, Please try another Email.';	
} else {

$passtoken=uniqid(mt_rand(), true);
mysqli_query($link_connect,"update bo_admins set token='".$passtoken."' where email='".Q($themail)."'");	
	
$connlist = mysqli_fetch_array($conn);
$xzname = $connlist['name'];
$xzemail = $connlist['email'];
$message ='<html>
<head>
<title>Forgot Password</title>
<meta http-equiv=Content-Type content=text/html; charset=utf-8>
<style type="text/css">
<!--
body { font-family: Arial; font-size: 13px; } 
td { font-size: 13px; } 
.mainc { background-color: #e1e1e1; color:#333; text-align:right; } 
.secc a { color: #333; } 
.secc { background-color: #f8f8f8; color:#333; } 
a { color: #333; text-decoration: none; } 
--></style></head><body>

Dear <strong>'.$xzname.'</strong>,<br><br>

You or Someone else requested '.$bo_sitename.' Account Credentials Information to be Reset. If you did request the Reset please follow the link below or you can safely disregard it.<br><br>
<table  cellspacing="2" cellpadding="1" border="0" width="100%">
<tr>
<td class="mainc">Reset Link:</td>
<td class="secc"><a href="'.BURL.'backend/login.php?d=reset&i='.$connlist['id'].'&t='.$passtoken.'">'.BURL.'backend/login.php?d=reset&i='.$connlist['id'].'&t='.$passtoken.'"</a></td>
</tr>
<tr>
<td class="mainc">Email:</td>
<td class="secc"><b>'.$xzemail.'</b></td>
</tr>
<tr>
<td class="mainc">IP Logged:</td>
<td class="secc"><b>'.getenv("REMOTE_ADDR").'</b></td>
</tr>
</table><br>

If you require assistance please do not hesitate to contact us,<br><br>

Regards,<br>
<br>
'.$bo_sitename.'<br><strong>Adminitration Team.</strong><br></body></html>';


	$toname=$xzname;
	$toemail=$xzemail;
	$bcc='';
	$cc='';
	$fromname=$bo_sitename;
	$fromemail=$bo_email;
	$subject=$bo_sitename." backend Account Information";
	$replytoname=$bo_sitename;
	$replytoemail=$bo_email;
	
	#echo $message; 
	
	#emailer($toname,$toemail,$bcc,$cc,$fromname,$fromemail,$subject,$replytoname,$replytoemail,$message,$message);

$return['error'] = false;
$return['msg'] = 'Reset Information has been sent to your Email Address. Check your Email and follow instructions.';
}
}

echo json_encode($return);
?>