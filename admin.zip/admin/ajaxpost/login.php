<? 

require '../includes/config.php';
require '../includes/functions.php';

session_start();


if (isemail($_POST['email']) == '0') {
$return['error'] = true;
$return['msg'] = 'Please enter a Valid Email Address.';

} else {
$themail = $_POST['email'];
$thepassword = $_POST['password'];
$connli = mysqli_query($link_connect,"SELECT * FROM bo_admins where email = '".Q($themail)."' and password='".Q(md5($thepassword))."' "); 
$rowsli = mysqli_num_rows($connli);
if ($rowsli == '0') {
$return['error'] = true;
$return['msg'] = 'Invalid Email or Password.';	

} else {

$clientinfo = mysqli_fetch_array($connli);

$_SESSION['admin_name'] = $clientinfo['name'];
$_SESSION['admin_role'] = $clientinfo['type'];
$_SESSION['admin_id'] = $clientinfo['id'];

$_SESSION[$sessobject_name] = 'true';

//echo $_SESSION[$sessobject_name];
$site_langs=array();
$site_langs[] = $_SESSION['prim_lang']='en';  



 $_SESSION['site_lang']=$site_langs; 
	  
$return['error'] = false;
$return['link'] = 'index.php';

}
}

echo json_encode($return);
?>