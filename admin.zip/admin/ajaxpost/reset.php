<? 

require '../includes/config.php';
require '../includes/functions.php';

session_start();

$cn=mysqli_query($link_connect,"select * from bo_admins where id='".Q($_GET['i'])."' and token='".Q($_GET['t'])."'");

if (mysqli_num_rows($cn)) {
	$return['error'] = true;
	$return['msg'] = 'Could not Find Record in the DB, Please Reset your Password Again.';
} else if (strlen($_POST['password'])<8) {
	$return['error'] = true;
	$return['msg'] = 'Password should be at least 8 Characters';
} else if ($_POST['password']!=$_POST['retypepassword']) {
	$return['error'] = true;
	$return['msg'] = 'Passwords does not match';
} else {
	
	mysqli_query($link_connect,"update bo_admins set password='".Q(md5($_POST['password']))."',  token='' where id='".Q($_POST['i'])."'");
	
	$return['error'] = false;
	$return['msg'] = 'Password Successfully changed. <a href="login.php">Click Here to Login</a>';	
}

echo json_encode($return);
?>