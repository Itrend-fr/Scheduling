<? if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();}
ob_start();

/** To avoid non Admins to check this page*/
if($_SESSION['admin_role'] == 'SuperAdmin'){

$role_filter=isset($_GET['role_filter'])?$_GET['role_filter']:'';
if (!$role_filter) { $role_filter='All';}

 $menu_filter=isset($_GET['menu_filter'])?$_GET['menu_filter']:'';
if (!$menu_filter || !isSet($_GET['mid'])) { $menu_filter='Main';}

$standalone_filter=isset($_GET['standalone_filter'])?$_GET['standalone_filter']:'';
if (!$standalone_filter) { $standalone_filter='All';}

$active_filter=isset($_GET['active_filter'])?$_GET['active_filter']:'';
if (!$active_filter) { $active_filter='All';}

$mid=isset($_GET['mid'])?$_GET['mid']:'';

$action = isset($_REQUEST['action'])?$_REQUEST['action']:'';
$showing = $page_pagination = $qry = $page = "";
switch ($action):
case "add":
	$name = '';
	$url = '';
	$incfile = '';
	$main_table = '';
	$boid = '';
	$role = '';
	$standalone = '';
	$active = '';
	$pos='';
	$showing = "record";
break;

case "edit":
	$strSQL="select * from bo_interface where id='".Q($_REQUEST['id'])."' order by pos";
	$objRS=mysqli_query($link_connect,$strSQL);
	if ($row=mysqli_fetch_object($objRS)){
	$name = $row->name;
	$url = $row->url;
	$incfile = $row->incfile;
	$main_table = $row->main_table;
	$boid = $row->boid;
	$role = $row->role;
	$standalone = $row->standalone;
	$active = $row->active;
	$pos=$row->pos;
	}
	
	$showing = "record";
break;

case "editexe":
case "addexe":
	$name = trime($_POST['name']);
	$url = trime($_POST['url']);
	$incfile = trime($_POST['incfile']);
	$main_table = trime($_POST['main_table']);
	$boid = trime($_POST['boid']);
	$role = trime($_POST['role']);
	$standalone = trime($_POST['standalone']);
	$active = trime($_POST['active']);
	$pos=trime($_POST['pos']);
	
	
	//Conditions
	switch(true):
	case $name=="" : $msg="Name cannot be empty!"; break;
	case $boid!=0 && $url=="" : $msg="URL cannot be empty!"; break;
	case $boid!=0 && $incfile=="" : $msg="Incfile cannot be empty!"; break;
	case  !validateNumeric($pos): $msg="Display Order  is required and  should be of Numeric Values."; break;
	endswitch;

	//If conditions are fine
	
	if (!isset($msg) || $msg==""):
	$strSQL="bo_interface set 
	name = '".Q($name)."',
	url = '".Q($url)."',
	incfile = '".Q($incfile)."',
	main_table = '".Q($main_table)."',
	boid = '".Q($boid)."',
	role = '".Q($role)."',
	standalone = '".Q($standalone)."',
	active = '".Q($active)."',
	pos='".Q($pos)."'";
	
	
	
	if ($action=="editexe") $strSQL ="update ".$strSQL." where id=".Q($_POST['id']); else $strSQL ="insert into ".$strSQL;
	
	#echo $strSQL;
	
	mysqli_query($link_connect,"SET NAMES 'utf8'");
	mysqli_query($link_connect,$strSQL);
	
	else:
	$action = substr ($action,0,strlen($action)-3);
	$showing = "record";
	endif;

break;

case "delete":
	if (isset($_POST['ids']) && $_POST['ids']) {
		foreach ($_POST['ids'] as $ids_item){
			$cn=mysqli_query($link_connect,"select * from bo_interface where boid='".Q($ids_item)."'");
			if (mysqli_num_rows($cn)) {
				$msg='Section cannot be Deleted because it contains sub Sections!';
				$msgalert='danger';
			} else {
				$strSQL="delete from bo_interface where id = '".Q($ids_item)."'";
				mysqli_query($link_connect,$strSQL);
				$msg='Section Deleted Successfully!';
				$msgalert='success';
			}
		}
	}

endswitch;
?>

<?
switch ($showing):
case "record":
?>

<form action="index.php?goto=<?=$_GET['goto']?>&page=<?=$page?>&menu_filter=<?=$menu_filter?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&mid=<?=$mid?>" method="post" role="form"  enctype="multipart/form-data">
<? if(isset($msg) && $msg) {?><div class="alert alert-danger" role="alert"><?=$msg?></div><? }?>

<div class="form-group">
    <label for="name">Name</label>
<input name="name" type="text" id="name" value="<? echo textencode($name) ?>"  class="form-control"></div>
 <div class="form-group">
    <label for="boid">Section Location</label>
 <select class="form-control" id="boid" name="boid">
 <option value="0" > - Main Menu - </option>
  
 <? $strSQL1="select * from bo_interface where boid = 0 and standalone = 'no' order by pos"; 
$objRS1=mysqli_query($link_connect,$strSQL1);
if($objRS1)
 while($ktnrow = mysqli_fetch_assoc($objRS1)){ ?>
  <option value="<? echo $ktnrow['id']; ?>" <? if($ktnrow['id'] == $boid ){echo 'selected';} ?>><? echo $ktnrow['name']; ?></option>
<? } ?>

<option value="9999" <? if ($boid=='9999') {?> selected<? }?>>Orphan</option>
</select>
</div>
<div class="form-group">
    <label for="standalone">Standalone</label>
<select name="standalone" id="standalone" class="form-control">
<option value="No"  <? if($standalone == 'No' || ($action=='add' && $standalone_filter=='No')){echo 'selected';} ?>>No</option>
<option value="Yes" <? if($standalone == 'Yes' || ($action=='add' && $standalone_filter=='Yes')){echo 'selected';} ?>>Yes</option>

</select>
</div>
<div class="form-group">
    <label for="url">URL Name <span class="small">(Leave Empty if Main Category // name if page // .php file if standalone is Yes)</span> </label>
<input name="url" type="text" id="url" value="<? echo textencode($url) ?>"  class="form-control"></div>

<div class="form-group">
    <label for="incfile">PHP Include File <span class="small">(Leave Empty if Main Category)</span></label>
    <div class="input-group">
        <div class="input-group-addon">pages/</div>
<input  name="incfile" type="text" id="incfile" value="<? echo textencode($incfile) ?>"  class="form-control"></div></div>


<div class="form-group">
    <label for="main_table">Main DB Table</label>
    <select class="form-control" name="main_table" id="main_table">
     <option value=""> - Select Table - </option>
    <? $res = mysqli_query($link_connect,"SHOW TABLES");
		while ($row = mysqli_fetch_array($res)) {?>
    <option value="<?=$row[0]?>" <? if ($main_table==$row[0]) {?> selected<? }?>><?=$row[0]?></option>
    <? } ?>
    </select>
    </div>

  <div class="form-group">
    <label for="role">Privileges</label>
<select name="role" id="role" class="form-control">
<option value="User"  <? if($role == 'User' || ($action=='add' && $role_filter=='User')){echo 'selected';} ?>>User (Everyone can see this)</option>
<option value="Admin" <? if($role == 'Admin' || ($action=='add' && $role_filter=='Admin')){echo 'selected';} ?>>Admin (SuperAdmin and Admin can see this)</option>
<option value="SuperAdmin" <? if($role == 'SuperAdmin' || ($action=='add' && $role_filter=='SuperAdmin')){echo 'selected';} ?>>SuperAdmin (Only SuperAdmin can see this)</option>
</select>
</div>

<div class="form-group">
    <label for="active">Active</label>
<select name="active" id="active" class="form-control">
<option value="Yes" <? if($active == 'Yes' || ($action=='add' && $active_filter=='Yes')){echo 'selected';} ?>>Yes</option>
<option value="No"  <? if($active == 'No' || ($action=='add' && $active_filter=='No')){echo 'selected';} ?>>No</option>
</select>
</div>
<div class="form-group">
				<label for="pos">Display Order: <span class="text-danger">*</span></label>
				<input name="pos" type="text" class="form-control" id="pos" dir="" value="<?=textencode($pos)?>" /></div>

<div align="right">
<input type="hidden" name="action" value="<? echo $action; ?>exe">
<input type="hidden" name="id" value="<? echo Q(isset($_REQUEST['id'])?$_REQUEST['id']:''); ?>">
<input type="submit" value="Save" class="btn btn-primary" />
</div>
</form>
<div align="center" >
<a href="index.php?goto=<?=$_GET['goto']?>&page=<?=$page?>&menu_filter=<?=$menu_filter?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&mid=<?=$mid?>" >Back To List</a>
</div>
<?
break;
default:

$qry='';
if ($role_filter=='User') {
	$qry=" where role='User'";
} else if ($role_filter=='Admin') {
	$qry=" where (role='Admin' or role='User')";
} else if ($role_filter=='SuperAdmin') {
	$qry=" where (role='SuperAdmin' or role='Admin' or role='User')";
}

if ($standalone_filter=='No' || $standalone_filter=='Yes') {
	if ($qry) { $qry.=' and '; } else { $qry=' where '; }
	$qry.=" standalone='".$standalone_filter."'";
}
 
if ($active_filter=='Yes' || $active_filter=='No') {
	if ($qry) { $qry.=' and '; } else { $qry=' where '; }
	$qry.=$where." active='".$active_filter."'";
} 


if ($qry) { $qry.=' and '; } else { $qry=' where '; }
if (isset($mid) && $mid) {
	$qry.= " boid = '".$_GET['mid']."'";	
} else {
	if ($menu_filter=='Main' || !$menu_filter) {
		$qry.=" boid='0'";
	} else if ($menu_filter=='Orphan') {
		$qry.=" boid='9999'";
	}	
}

#$page=$_GET['page'];
$offset = 25;
$page=isset($_GET['page']) && $_GET['page']?$_GET['page']:0;
if (is_numeric($page) || $page==0) {
	$page_offset=intval($page)*$offset;
} 

$strSQL="select * from bo_interface ".$qry." order by pos asc LIMIT ".$page_offset.",".$offset;

$objRS=mysqli_query($link_connect,$strSQL);
$nbrow=mysqli_num_rows($objRS);

$result = @mysqli_query($link_connect,"select * from bo_interface ".$qry);
$maxrows = mysqli_num_rows($result);
$nos = ceil($maxrows/$offset);
?>

<? if(isset($msg) && $msg) {?><div class="alert alert-<?=$msgalert?>" role="alert"><?=$msg?></div><? }?>

<form action="index.php?goto=<?=$_GET['goto']?>&page=<?=$page?>&menu_filter=<?=$menu_filter?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&mid=<?=$mid?>" method="post" name="del">

<div class="row">
<div class="col-md-12">
<h3><?=getfield("bo_interface","name","where id='".Q($mid)."' ")?></h3>
</div>
</div>

<div class="row">
<div class="col-md-8">
<script>
    $(function(){
		$('#filter_btn').bind('click',function(){
			var rolefilters = $('#rolefilters').val(); 
			var standalonefilters = $('#standalonefilters').val(); 
			var activefilters = $('#activefilters').val(); 
			var menufilters = $('#menufilters').val(); 
			if(typeof menufilters === 'undefined'){menufilters = "All";}
			if(rolefilters && standalonefilters && activefilters){
				window.location = 'index.php?goto=<?=$_GET['goto']?>&page=<?=$page?>&mid=<?=$_GET['mid']?>&menu_filter='+menufilters+'&role_filter='+rolefilters+'&standalone_filter='+standalonefilters+'&active_filter='+activefilters; // redirect
			}
			return false;		 
		});
  
    });
</script>


<select id="rolefilters" class="form-control" style="width:145px;display:inline-table;" onChange="">
<option value="All"> - All Privileges - </option>
<option <? if ($role_filter=='SuperAdmin') {?> selected<? }?> value="SuperAdmin">SuperAdmin</option>
<option <? if ($role_filter=='Admin') {?> selected<? }?> value="Admin">Admin</option>
<option <? if ($role_filter=='User') {?> selected<? }?> value="User">User</option>
</select>
<select id="standalonefilters" class="form-control" style="width:160px;display:inline-table;" onChange="">
<option value="All"> - All Standalone - </option>
<option <? if ($standalone_filter=='Yes') {?> selected<? }?> value="Yes">Yes</option>
<option <? if ($standalone_filter=='No') {?> selected<? }?> value="No">No</option>
</select>
<select id="activefilters" class="form-control" style="width:140px;display:inline-table;" onChange="">
<option value="All"> - Active Types - </option>
<option <? if ($active_filter=='Yes') {?> selected<? }?> value="Yes">Yes</option>
<option <? if ($active_filter=='No') {?> selected<? }?> value="No">No</option>
</select>
<? if(!isset($_GET['mid']) || !$_GET['mid']){?>
<select id="menufilters" class="form-control" style="width:125px;display:inline-table;" onChange="">
<option <? if ($menu_filter=='Main') {?> selected<? }?> value="Main">Main</option>
<option <? if ($menu_filter=='Orphan') {?> selected<? }?> value="Orphan">Orphan</option>
</select>
<? } ?>
 <input type="button" value="Filter" class="btn btn-primary" id="filter_btn"/>
 </div>


<div class="col-md-4" align="right"><input type='hidden' name="action" value="delete">
<input type="button" value="Delete" class="btn btn-primary" onclick="conf()"> 
<input type="button" value="Add" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add&page=<?=$page?>&menu_filter=<?=$menu_filter?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&mid=<?=$mid?>'">
</div>
</div>


<div class="table-responsive">
<table class="table table-striped" <? if ($role_filter=='All' && $standalone_filter=='All' && $active_filter=='All') {?>id="sortablelist"<? }?>>
<thead class="no">
<th>&nbsp;</th>
<th>Name</th>
<th>Standalone</th>
<th>URL</th>
<th>Include File (pages/)</th>
<th>DB Table</th>
<th>Privileges</th>
<th>Active</th>
<th>Display Order</th>
<th></th>
</thead>
<? $counter=0;
while ($row=mysqli_fetch_object($objRS)):?>
<tr itemID="<?=$row->id?>" class="stcursor">
<td valign="top"><input type="checkbox" name="ids[]" value="<? echo $row->id; ?>" ></td>
<td ><? echo $row->name;?></td> 
<td ><? echo $row->standalone;?></td> 
<td ><? if ($row->standalone=='Yes' && $row->url) { echo '<a href="'.$row->url.'" target="_blank">'.$row->url.'</a>'; } else if($row->standalone=='No' && $row->url) { echo '<a href="index.php?goto='.$row->url.'" target="_blank">index.php?goto='.$row->url.'</a>'; }?></td> 
<td ><? echo $row->incfile;?></td> 
<td ><? echo $row->main_table;?></td> 
<td ><? if ($row->role=='User') { echo 'Everyone'; } else if ($row->role=='Admin') { echo 'SuperAdmin & Admin'; } else { echo 'SuperAdmin';  }?></td> 
<td ><? echo $row->active;?></td> 
<td ><? echo $row->pos;?></td> 

<td ><a href="index.php?goto=<?=$_GET['goto']?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&action=edit&amp;id=<?=$row->id?>&mid=<?=$mid?>">Edit</a>  <? if (checksubbo($row->id)) {?>
   | <a href="index.php?goto=<?=$_GET['goto']?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&mid=<? echo $row->id;?>"> Sub Sections</a> <? } ?> </td>
</tr>
<? endwhile; ?>
</table>
</div>

<div align="right" style="margin-bottom:5px;">
<input type='hidden' name="action" value="delete">
<input type="button" value="Delete" class="btn btn-primary" onclick="conf()"> 
<input type="button" value="Add" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add&page=<?=$page?>&menu_filter=<?=$menu_filter?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>&mid=<?=$mid?>'">
</div>
<div class="row">
<div class="col-md-12">
<ul class="pagination" style="margin:0">
<?
if ($nos > '1' ) {

			$range =7;
            $range_min = ($range % 2 == 0) ? ($range / 2) - 1 : ($range - 1) / 2;
            $range_max = ($range % 2 == 0) ? $range_min + 1 : $range_min;
            $page_min = $page+1- $range_min;
            $page_max = $page+1+ $range_max;

            $page_min = ($page_min < 1) ? 1 : $page_min;
            $page_max = ($page_max < ($page_min + $range - 1)) ? $page_min + $range - 1 : $page_max;
            if ($page_max > $nos) {
                $page_min = ($page_min > 1) ? $nos - $range + 1 : 1;
                $page_max = $nos;
            }

            $page_min = ($page_min < 1) ? 1 : $page_min;
			
			$page_pagination .='<li class="disabled"> <a href="javascript:void(0);">[ '.number_format($maxrows).' Records ]</a></li>';
			
            if ( ($page+1 > ($range - $range_min)) && ($nos > $range) ) {
                $page_pagination .= '<li><a href="index.php?goto='.$_GET['goto'].'&menu_filter='.$menu_filter.'&role_filter='.$role_filter.'&standalone_filter='.$standalone_filter.'&active_filter='.$active_filter.'&mid='.$mid.'&page=0">&laquo;&laquo;</a></li>';
            }

            if ($page+1 != 1) {
                $page_pagination .= '<li><a href="index.php?goto='.$_GET['goto'].'&menu_filter='.$menu_filter.'&role_filter='.$role_filter.'&standalone_filter='.$standalone_filter.'&active_filter='.$active_filter.'&mid='.$mid.'&page='.($page-1).'">&laquo;</a></li>';
            }

            for ($i = $page_min;$i <= $page_max;$i++) {
                $page_pagination.= '<li';
				if ($i == $page+1) { $page_pagination.= ' class="active"'; }
				$page_pagination.= '><a href="index.php?goto='.$_GET['goto'].'&menu_filter='.$menu_filter.'&role_filter='.$role_filter.'&standalone_filter='.$standalone_filter.'&active_filter='.$active_filter.'&mid='.$mid.'&page='.($i-1).'">'.$i.'</a></li>';
            }

            if ($page+1 < $nos) {
                $page_pagination.= '<li><a href="index.php?goto='.$_GET['goto'].'&menu_filter='.$menu_filter.'&role_filter='.$role_filter.'&standalone_filter='.$standalone_filter.'&active_filter='.$active_filter.'&mid='.$mid.'&page='.($page+1).'">&raquo;</a></li>';
            }


            if (($page+1< ($nos - $range_max)) && ($nos > $range)) {
                $page_pagination .= '<li><a href="index.php?goto='.$_GET['goto'].'&menu_filter='.$menu_filter.'&role_filter='.$role_filter.'&standalone_filter='.$standalone_filter.'&active_filter='.$active_filter.'&mid='.$mid.'&page='.($nos-1).'">&raquo;&raquo;</a></li>';
            }
 
        } 
		echo $page_pagination; 
        
		?> 

</ul>
</div>
</div>
<? if(isset($_GET['mid'])){?>
<div align="center" >
<a href="index.php?goto=<?=$_GET['goto']?>&page=<?=$page?>&menu_filter=<?=$menu_filter?>&role_filter=<?=$role_filter?>&standalone_filter=<?=$standalone_filter?>&active_filter=<?=$active_filter?>" >Back To List</a></div>
<? } ?>
</form>
<script language="javascript">
function conf(){
if (confirm("Are you sure you want to delete this/these record(s)?"))
document.forms["del"].submit(); 
}
</script>
<? endswitch; 
}
?>
