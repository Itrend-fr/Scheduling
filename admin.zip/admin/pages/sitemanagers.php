<? if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();} 

$action = isset($_REQUEST['action'])?$_REQUEST['action']:'';
$showing = "";
$qry = "";
$chqry = '';

switch ($action):

// Add
case "add":
	$name = '';
	$email = '';
	$type = '';
	
$showing = "record";
break;

// Edit
case "edit":
$objRS=mysqli_query($link_connect,"select * from bo_admins where id='".Q($_REQUEST['id'])."'");
if ($row=mysqli_fetch_object($objRS)){
	$name = $row->name;
	$email = $row->email;
	$type = $row->type;
}
$showing = "record";
break;

// Add or Edit Execution
case "editexe":
case "addexe":
	$name=trime($_POST['name']);
	$email=trime($_POST['email']);
	$password=trime($_POST['password']);
	$type=trime($_POST['type']);
	
	if ($action=='editexe') { $chqry=" and id!='".Q($_REQUEST['id'])."'"; } 
	$cnch=mysqli_query($link_connect,"select id from bo_admins where email='".Q($email)."' ".$chqry);
	// Checking Conditions
	switch(true):
	case isemail($email)=='': $msg="Email Address is not Valid"; break;
	case mysqli_num_rows($cnch): $msg="Email address associated with another account"; break;
	case (($password && $action=='editexe' || $action=='addexe') && strlen($password)<8): $msg="Password must be greater or equal to 8 characters!"; break;
	case strlen($name)=='': $msg="Full Name cannot be empty!"; break;
	case checkadmin($_REQUEST['id'],$type,$action)==false: $msg="There should be at least One Administrator"; break;
	endswitch;
	
	// If Conditions are fine
	if (!isset($msg) || $msg=="") {
		
		if ($action=='addexe' || ($action=='editexe' && $password)) {
			$qry=", password='".Q(md5($password))."'";
		}
		
		$strSQL="bo_admins set 
		email= '".Q($email)."',
		name= '".Q($name)."',
		type= '".Q($type)."'
		".$qry;
		
		if ($action=="editexe") {
			$strSQL ="update ".$strSQL." where id='".Q($_POST['id'])."'";
		} else {
			$strSQL ="insert into ".$strSQL;
		}
		mysqli_query($link_connect,"SET NAMES 'utf8'");
		mysqli_query($link_connect,$strSQL);
		#echo $strSQL;
	
	} else {
		$action = substr ($action,0,strlen($action)-3);
		$showing = "record";
	}
break;

// Deleting Records
case "delete":
if (isset($_POST['ids']) && $_POST['ids']) {
	foreach ($_POST['ids'] as $ids_item){
		$strSQL=mysqli_query($link_connect,"delete from bo_admins where id ='".Q($ids_item)."'");
	}
}

endswitch;
?>

<?
switch ($showing):
case "record":
?>
<form action="index.php?goto=<?=$_GET['goto']?>" method="post" role="form">
<? if(isset($msg) && $msg) {?><div class="alert alert-danger" role="alert"><?=$msg?></div><? }?>

  <div class="form-group">
    <label for="name">Full Name:</label>
    <input name="name" type="name" class="form-control" id="name" value="<? echo textencode($name) ?>">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input name="email" type="email" class="form-control" id="email" value="<? echo textencode($email) ?>">
  </div>
  <div class="form-group">
    <label for="pwd">Password: <small class="text-danger">(Leave Empty if you dont want to change it)</small></label>
    <input name="password" type="password" class="form-control" id="pwd" value="">
  </div>
  
   <div class="form-group">
    <label for="type">Role:</label>
    <select name="type" id="type" class="form-control">
<? if($_SESSION['admin_role'] == 'SuperAdmin'){ ?>
	    <option value="SuperAdmin" <? if ($type=='SuperAdmin') {?> selected="selected"<? } ?>>Super Administrator</option>
<? } ?>
    <option value="Admin" <? if ($type=='Admin') {?> selected="selected"<? } ?>>Administrator</option>
    <option value="User" <? if ($type=='User') {?> selected="selected"<? } ?>>Moderator</option>
    </select>
  </div>
  

<div align="right">
<input type="hidden" name="action" value="<? echo $action; ?>exe">
<input type="hidden" name="id" value="<? echo Q(isset($_REQUEST['id'])?$_REQUEST['id']:''); ?>">
<button type="submit" class="btn btn-primary">Save</button>
</div>
</form>
<div align="center">
<a href="index.php?goto=<?=$_GET['goto']?>">Back To List</a></div>
<?
break;
default:
$strSQL="select * from bo_admins";
if($_SESSION['admin_role'] != 'SuperAdmin'){
$strSQL.= " where type != 'SuperAdmin'";
}
$objRS=mysqli_query($link_connect,$strSQL);
?>
<form action="index.php?goto=<?=$_GET['goto']?>" method="post" name="del">
<div align="right" style="margin-bottom:5px;"><button type="button" class="btn btn-primary" onclick="conf()">Delete</button>
<button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add'">Add</button>
<input type=hidden name="action" value="delete">
</div>
<div class="table-responsive">
<table class="table table-striped">
<thead>
<th>&nbsp;</th>
<th>Full Name</th>
<th>Email</th>
<th>Role</th>
<th></th>
</thead>
<tbody>
<? $counter=0;
while ($row=mysqli_fetch_object($objRS)):
$color=(isset($color) && $color=="color1"?"color2":"color1");?>
<tr class="<? echo $color?>">
<td><input type="checkbox" name="ids[]" value="<? echo $row->id; ?>" <? if ($row->id == '1') { echo "disabled";} ?>></td>
<td><? echo $row->name; ?></td> 
<td><? echo $row->email; ?></td> 
<td><? if ($row->type=='Admin'){ echo 'Administrator';} else  if ($row->type=='SuperAdmin') { echo 'SuperAdministrator';} else{ echo 'Moderator';} ?></td> 
<td><a href="index.php?goto=<?=$_GET['goto']?>&action=edit&id=<? echo $row->id; ?>" title="Edit"><i class="glyphicon glyphicon-edit"></i></a></td>
</tr>
<? endwhile; ?>
</tbody>
</table>
</div>
</form>
<script language="javascript">
function conf(){
if (confirm("Are you sure you want to delete this/these record(s)?"))
document.forms["del"].submit(); 
}
</script>
<? endswitch; ?>
