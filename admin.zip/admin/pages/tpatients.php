<? 
	if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();} 
	
	$action = isset($_REQUEST['action'])?$_REQUEST['action']:''; 
    $showing = $qry = '';
	switch ($action):
	
	// Add
	case "add":	
        
        $pfirstname='';
		$plastname='';
		$gender='';
		$pemail='';
		$ptel='';
		$paddr='';
		$ppostcode='';
		$pcity='';
		$pcountry='';
		$dateofbirth='';
		$lang='';
		$contactinfo='';
        $luid = '';
        $showing = "record";
	break;
	
	// Edit
	case "edit":
		$cn=mysqli_query($link_connect,"select * from tpatient where pid='".Q($_GET['pid'])."'");
		$rs=mysqli_fetch_object($cn);
		$pfirstname=$rs->pfirstname;
		$plastname=$rs->plastname;
		$gender=$rs->gender;
		$pemail=$rs->pemail;
		$ptel=$rs->ptel;
		$paddr=$rs->paddr;
		$ppostcode=$rs->ppostcode;
		$pcity=$rs->pcity;
		$pcountry=$rs->pcountry;
		$dateofbirth=$rs->dateofbirth;
		$lang=$rs->lang;
		$contactinfo=$rs->contactinfo;
        $luid=$rs->luid;
						
		$showing = "record";
	break;
	
	// Add or Edit Execution
	case "editexe":
	case "addexe":
	foreach($_SESSION['site_lang'] as $value) { }
		$pfirstname=trime($_POST['pfirstname']); 
	 $plastname=trime($_POST['plastname']); 
	 $gender=trime($_POST['gender']); 
	 $pemail=trime($_POST['pemail']); 
	 $ptel=trime($_POST['ptel']); 
	 $paddr=trime($_POST['paddr']); 
	 $ppostcode=trime($_POST['ppostcode']); 
	 $pcity=trime($_POST['pcity']); 
	 $pcountry=trime($_POST['pcountry']); 
	 $dateofbirth=trime($_POST['dateofbirth']); 
	 $lang=trime($_POST['lang']); 
	 $contactinfo=trime($_POST['contactinfo']); 
	 $luid=trime($_POST['luid']); 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	
		// Checking Conditions 
		 switch(true):
        case  !$pfirstname: $msg="First Name  is required and  cannot be empty."; break; 
		case  !$plastname: $msg="Last Name  is required and  cannot be empty."; break; 
		case  !$gender: $msg="Gender  is required and  cannot be empty."; break; 
		case  !isemail($pemail): $msg="Email  is required and  should be a valid Email Address."; break; 
		case $ptel &&  !validatePhone($ptel): $msg="Telephone  is required and  should have a correct format (e.g. 9613000000)."; break; 
		case $ppostcode &&  !$ppostcode: $msg="Postcode  is required and  cannot be empty."; break; 
		case $pcity &&  !$pcity: $msg="City  is required and  cannot be empty."; break; 
		case $pcountry &&  !$pcountry: $msg="Country  is required and  cannot be empty."; break; 
		case $dateofbirth &&  !validateDate($dateofbirth,"Y-m-d"): $msg="Date Of Birth  is required and  should have a correct format YYYY-MM-DD (e.g. ".date("Y-m-d",strtotime("now")).")."; break; 
		case $lang &&  !$lang: $msg="Lang  is required and  cannot be empty."; break;
        case  !$luid: $msg="User  is required and   should have a value selected."; break;
		 endswitch;
	
		// If Conditions are fine
		if (!isset($msg) || $msg=="") {
		    $sqlqry="";
		
			$strSQL="tpatient set 
				".$sqlqry."
		pfirstname='".Q($pfirstname)."',
			plastname='".Q($plastname)."',
			gender='".Q($gender)."',
			pemail='".Q($pemail)."',
			ptel='".Q($ptel)."',
			paddr='".Q($paddr)."',
			ppostcode='".Q($ppostcode)."',
			pcity='".Q($pcity)."',
			pcountry='".Q($pcountry)."',
			dateofbirth='".Q($dateofbirth)."',
			lang='".Q($lang)."',
			contactinfo='".Q($contactinfo)."',
			luid='".Q($luid)."'
			";
			
			if ($action=="editexe") {
			$strSQL ="update ".$strSQL." where pid='".Q($_POST['pid'])."'";
			} 
			if ($action=="addexe") {
			$strSQL ="insert into ".$strSQL;
			} 
				
			#echo $strSQL;
			mysqli_query($link_connect,"SET NAMES 'utf8'");
			mysqli_query($link_connect,$strSQL) or die(mysqli_error($link));
			
			unset($_SESSION['csrf_token_'.$_GET['goto']]);
		
		} else {
			$action = substr ($action,0,strlen($action)-3);
			$showing = "record";
			$msgerr="danger";
		}
		

		
	break;
	
	// Deleting Records
	case "delete":
	
	if (isset($_POST['ids']) && $_POST['ids']) {

		
		foreach ($_POST['ids'] as $ids_item){
			
			$cndel=mysqli_query($link_connect,"select pid,plastname from tpatient where pid ='".Q($ids_item)."'");
			if (mysqli_num_rows($cndel)) {
                $rsdel=mysqli_fetch_object($cndel);
                // delete
                $delrec=1;
                $msgsuccessnames[]=$rsdel->plastname;
                if ($delrec) {
            
                    mysqli_query($link_connect,"delete from tpatient where pid ='".Q($ids_item)."'");
                    $msgsuccess="<b>".@implode(", ",$msgsuccessnames)."</b> Deleted Successfully";
                }
			}
	    }
	
	}
	endswitch;		
		
	switch ($showing):
		
	case "record":
	
	if(isset($msg) && $msg) {?>
	<div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div>
	<? }?>

	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" role="form" enctype="multipart/form-data">
	<div class="form-group">
				<label for="pfirstname">First Name: <span class="text-danger">*</span></label>
				<input name="pfirstname" type="text" class="form-control" id="pfirstname" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($pfirstname)?>" /></div><div class="form-group">
				<label for="plastname">Last Name: <span class="text-danger">*</span></label>
				<input name="plastname" type="text" class="form-control" id="plastname" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($plastname)?>" /></div>
				<div class="form-group">
					<label for="gender">Gender: <span class="text-danger">*</span></label>
					<script>
				$(document).ready(function() {
					$('.egender_filter_select2').select2();
				});
				</script>
				<select name="gender" id="gender" class="form-control egender_filter_select2" >
				<option value="" > - Select Gender - </option>
				<? $cnrel=mysqli_query($link_connect,"select id,text_en from tgender ".$qry." order by text_".$_SESSION['prim_lang']." asc");
				while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
				<option value="<?=$rsrel->id?>" <? if($gender==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->{"text_en"}?></option>
				<?	} ?>
				</select></div>
				<div class="form-group">
				<label for="pemail">Email: <span class="text-danger">*</span></label>
				<input name="pemail" type="email" class="form-control" id="pemail" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($pemail)?>" /></div><div class="form-group">
				<label for="ptel">Telephone: </label>
				<input name="ptel" type="text" class="form-control" id="ptel" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($ptel)?>" /><div><small class="text-warning"><em>Use only numeric values.</em></small></div></div><script type="text/javascript" src="plugins/tinymce/tinymce.min.js"></script>
			<div class="form-group">
				<label for="paddr">Address: </label>
				<script type="text/javascript">
	tinymce.init({
    selector: "textarea.paddr",
    themes: "modern",
	height: 300,
	directionality : 'ltr',
	cleanup_on_startup : true,
	force_br_newlines : false,
      force_p_newlines : false,
      forced_root_block : '',
    plugins: [
        "advlist autolink lists link image charmap preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code",
        "insertdatetime media nonbreaking save table contextmenu directionality",
        "paste textcolor colorpicker textpattern responsivefilemanager"
    ],
    toolbar1: " undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    toolbar2: "preview media | forecolor backcolor",
    image_advtab: true,
	paste_text_sticky : true,
	external_filemanager_path:"plugins/filemanager/",
	filemanager_title:"Photo / Video Manager" ,
	external_plugins: { "filemanager" : "../filemanager/plugin.min.js"},	
	oninit: function (ed) {
        ed.pasteAsPlainText = true;
    }
});
</script>
<textarea name="paddr" id="paddr" class="paddr" style="width:100%;"><?=textencode($paddr)?></textarea></div><div class="form-group">
				<label for="ppostcode">Postcode: </label>
				<input name="ppostcode" type="text" class="form-control" id="ppostcode" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($ppostcode)?>" /></div>
                <div class="form-group">
				<label for="pcountry">Country: </label>
				<script>
			$(document).ready(function() {
				$('.pcountry_filter_select2').select2();
			});
			</script>
			<select name="pcountry" id="pcountry" class="form-control pcountry_filter_select2" >
			<option value="" > - Select Country - </option>
			<? $cnrel=mysqli_query($link_connect,"select id,label from tcountry ".$qry." order by label asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->id?>" <? if($pcountry==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
			<?	} ?>
			</select></div>
                <div class="form-group">
				<label for="pcity">City: </label>
				<input name="pcity" type="text" class="form-control" id="pcity" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($pcity)?>" /></div>
                <!--<div class="form-group">
                    <label for="pcountry">Country: </label>
                    <input name="pcountry" type="text" class="form-control" id="pcountry" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($pcountry)?>" />
                </div>-->
                
            <div class="form-group">
				<label for="dateofbirth">Date Of Birth: </label>
				<div class="input-group date" id="date-dateofbirth">
					<input name="dateofbirth" type="text" class="form-control" id="dateofbirth" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<? if ($dateofbirth) {echo $dateofbirth; }?>" />
					<span class="input-group-addon btn-success">
					<span class="glyphicon glyphicon-calendar"></span>
					</span>
					</div>
					<script type="text/javascript">
					$(function () {
						$('#date-dateofbirth').datetimepicker({
							format: 'YYYY-MM-DD'	
						});
					});
					</script></div>
                    <!--<div class="form-group">
				    <label for="lang">Lang: </label>
				    <input name="lang" type="text" class="form-control" id="lang" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($lang)?>" />
                </div>-->
                <div class="form-group">
				<label for="lang">Lang: </label>
				<script>
			$(document).ready(function() {
				$('.lang_filter_select2').select2();
			});
			</script>
			<select name="lang" id="lang" class="form-control lang_filter_select2" >
			<option value="" > - Select Lang - </option>
			<? $cnrel=mysqli_query($link_connect,"select id,label from tlanguage ".$qry." order by id asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->id?>" <? if($lang==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
			<?	} ?>
			</select></div>
            <div class="form-group">
				<label for="contactinfo">Contact Info: </label>
				<textarea name="contactinfo" id="contactinfo" class="form-control" style="width:100%;height:150px;"><?=textencode($contactinfo)?></textarea></div>
                <div class="form-group">
				<label for="luid">User: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.luid_filter_select2').select2();
			});
			</script>
			<select name="luid" id="luid" class="form-control luid_filter_select2" >
			<option value="" > - Select User - </option>
			<? $cnrel=mysqli_query($link_connect,"select uid,login from tuser ".$qry." order by uid asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->uid?>" <? if($luid==$rsrel->uid) { echo " selected "; } ?>><?=$rsrel->login?></option>
			<?	} ?>
			</select></div>
	<div align="right">
	<input type="hidden" name="action" value="<?=$action?>exe">
	<input type="hidden" name="pid" value="<?=isset($_REQUEST['pid'])?$_REQUEST['pid']:''?>">
	<button type="button" class="btn btn-danger" onClick="window.location='index.php?goto=<?=$_GET['goto']?>'"> <i class="glyphicon glyphicon-open"></i> Cancel</button>  <button type="submit" class="btn btn-primary pull-right" style="margin-left:4px;"> <i class="glyphicon glyphicon-save"></i> Save</button> </div>
	</form>
	
	<div align="center"  class="larecords">
	<a href="index.php?goto=<?=$_GET['goto']?>">List All Records</a>
	</div>
	<?	
	break;
	
	default:
	
	
	$cn=mysqli_query($link_connect,"select * from tpatient ".$qry." order by pid desc");
	
	
	
	?>
	<? if (isset($msgerr) && $msgerr) {?>
	<div role="alert" class="alert alert-danger"><?=$msgerr?></div>
	<? }?>
	<? if (isset($msgsuccess) && $msgsuccess) {?>
	<div role="alert" class="alert alert-success"><?=$msgsuccess?></div>
	<? }?>
	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" name="del">
	<div id="toolbar" class="btn-group noprint">
	<button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add'">
			<i class="glyphicon glyphicon-plus"></i> Add
		</button>
		<button type="button" class="btn btn-primary" onclick="conf()">
			<i class="glyphicon glyphicon-trash"></i> Delete
		</button><button type="button" class="btn btn-success" onclick="window.print();">
        <i class="glyphicon glyphicon-print"></i> Print
    </button>
	</div>
	<table 
	data-toggle="table" 
	data-escape="false"  
    data-classes="table table-hover table-condensed"
	data-striped="true"
	data-cache="false"
	data-show-footer="false"
	
		data-show-refresh="false"
		 data-search="true"
	 
	data-show-toggle="false"
	data-show-columns="true"
	data-toolbar="#toolbar"
	data-pagination="true"
    data-page-list="[10,25,50,100,All]"
    data-page-size="25"	
    data-show-export="true"
    data-export-types="['csv', 'txt', 'excel']"
	>
	<thead>
	<th class="text-center"><input type="checkbox" name="ids[]" onClick="toggle_checkbox(this)"></th>
			<th data-visible="false"  data-field="pid" data-halign="center"  data-align="left">Pid</th>
		<th data-field="pfirstname" data-halign="center"  data-align="left">First Name <span class="text-danger">*</span> </th>
		<th data-field="plastname" data-halign="center"  data-align="left">Last Name <span class="text-danger">*</span> </th>
		<th data-visible="false"  data-field="gender" data-halign="center"  data-align="left">Gender <span class="text-danger">*</span> </th>
		<th data-field="pemail" data-halign="center"  data-align="left">Email <span class="text-danger">*</span> </th>
		<th data-visible="false"  data-field="ptel" data-halign="center"  data-align="left">Telephone</th>
		<th data-visible="false"  data-field="paddr" data-halign="center"  data-align="left">Address</th>
		<th data-visible="false"  data-field="ppostcode" data-halign="center"  data-align="left">Postcode</th>
		<th data-visible="false"  data-field="pcity" data-halign="center"  data-align="left">City</th>
		<th data-visible="false"  data-field="pcountry" data-halign="center"  data-align="left">Country</th>
		<th data-visible="false"  data-field="dateofbirth" data-halign="center"  data-align="left">Date Of Birth</th>
		<th data-visible="false"  data-field="lang" data-halign="center"  data-align="left">Lang</th>
		<th data-visible="false"  data-field="contactinfo" data-halign="center"  data-align="left">Contact Info</th>
		<th data-visible="false"  data-field="pdatec" data-halign="center"  data-align="left">Date Created</th>
		<th data-visible="false"  data-field="pdatem" data-halign="center"  data-align="left">Last Modified</th>
		<th data-visible="false"  data-field="puidm" data-halign="center"  data-align="left">Modified By</th>
		<th data-field="luid" data-halign="center"  data-align="left">User</th>
		<th data-field="action" data-halign="center"  data-align="left" data-editable="true">Action</th>
		
	</thead><tbody>
		<? while ($rs=mysqli_fetch_object($cn)) {?>
		<tr <? if (isset($_REQUEST['pid']) && $rs->pid==$_REQUEST['pid']) {?> class="success" <? }?>>
		<td><input type="checkbox" name="ids[]" value="<?=$rs->pid?>"></td>
			<td><?=$rs->pid?></td>
				<td ><?=$rs->pfirstname?></td>
				<td ><?=$rs->plastname?></td>
				<td ><?=getfield("tgender","text_en", " where id='".Q($rs->gender)."'")?></td>
				<td ><a href="mailto:<?=$rs->pemail?>"><?=$rs->pemail?></a></td>
				<td ><?=$rs->ptel?></td>
				<td ><?=strip_tags($rs->paddr,'<img><p><b><em><strong><a><i><u><ul><ol><li><br><br />')?></td>
				<td ><?=$rs->ppostcode?></td>
				<td ><?=$rs->pcity?></td>
				<td ><?=getfield("tcountry","label", "where id='".Q($rs->pcountry)."'")?></td>
				<td ><?=date_disp("D, d M Y",$rs->dateofbirth,'',$_SESSION["prim_lang"])?></td>
				<td ><?=getfield("tlanguage","label", "where id='".Q($rs->lang)."'")?></td>
				<td ><?=strip_tags($rs->contactinfo,'<img><p><b><em><strong><a><i><u><ul><ol><li><br><br />')?></td>
				<td ><?=date_disp("D, d M Y h:i A",$rs->pdatec,'',$_SESSION["prim_lang"])?></td>
				<td ><?=date_disp("D, d M Y h:i A",$rs->pdatem,'',$_SESSION["prim_lang"])?></td>
				<td><?=getfield("tuser","login", " where uid='".Q($rs->puidm)."'")?></td>
				<td><?=getfield("tuser","login", " where uid='".Q($rs->luid)."'")?></td>
				<td><a href="index.php?goto=<?=$_GET['goto']?>&pid=<?=$rs->pid?>&action=edit" title="Edit"><i class="glyphicon glyphicon-edit"></i></a> </td></tr>
		
		<? } ?>
	</tbody>
	</table>
	<input type=hidden name="action" value="delete">
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto'].'_del'] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>_del" value="<?php echo $token; ?>">	
	
	</form>
		
	
	<script language="javascript">
	function conf(){
		if (confirm("Are you sure you want to delete this/these record(s)?")) {
			document.forms["del"].submit(); 
		}
	}
	</script>
	<? endswitch; ?>