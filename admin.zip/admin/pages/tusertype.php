<? if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();}
	
	$action = isset($_REQUEST['action'])?$_REQUEST['action']:''; 
	$showing = $qry = "";
	switch ($action):
	
	// Add
	case "add": 	
		$label='';
		$description = '';
        $rights = '';
		$showing = "record";
	break;
	
	// Edit
	case "edit":
		$cn=mysqli_query($link_connect,"select * from tusertype where id='".Q($_GET['id'])."'");
		$rs=mysqli_fetch_object($cn);
		$label=$rs->label;
        $description=$rs->description;
        $rights=$rs->rights;
		
		$showing = "record";
	break;
	
	// Add or Edit Execution
	case "editexe":
	case "addexe":
	$label=trime($_POST['label']);
    $description=trime($_POST['description']);
    $rights=trime($_POST['rights']);
	

		// Checking Conditions
		
		/*$descrerr='';
			foreach($_SESSION['site_lang'] as $value) {
				if (!${$value}) { $descrerr='true'; }
		}
		*/		
		switch(true):
		case !$label: $msg="Label cannot be empty."; break;
			
		endswitch;
	
		// If Conditions are fine
		if (!isset($msg) || $msg=="") {
			
			$sqlqry='';
			if ($action=="addexe") {
                $qtid = mysqli_query($link_connect,"select id from tusertype order by id desc limit 1");
                if(mysqli_num_rows($qtid)){
                    $rtid = mysqli_fetch_object($qtid);
                    $tid = $rtid->id+1;
                }else{
                    $tid = 1;
                }
                $sqlqry=" id='".Q($tid)."', ";
            }
						
			$strSQL="tusertype set 
			".$sqlqry."
			label='".Q($label)."',
            description='".Q($description)."',
            rights='".Q($rights)."'
			";
			
			if ($action=="editexe") {
			$strSQL ="update ".$strSQL." where id='".Q($_POST['id'])."'";
			}  
			if ($action=="addexe") {
			$strSQL ="insert into ".$strSQL;
			} 
			 
			#echo $strSQL;
			mysqli_query($link_connect,"SET NAMES 'utf8'");
			mysqli_query($link_connect,$strSQL) or die(mysqli_error($link_connect));
		
		
		} else {
			$action = substr ($action,0,strlen($action)-3);
			$showing = "record";
			$msgerr="danger";
		}
		

		
	break;
	
	// Deleting Records
	case "delete":
	
	if (isset($_POST['ids']) && $_POST['ids']) {
		foreach ($_POST['ids'] as $ids_item){
			
			$cndel=mysqli_query($link_connect,"select id,label from tusertype where id ='".Q($ids_item)."'");
			if (mysqli_num_rows($cndel)) {
			$rsdel=mysqli_fetch_object($cndel);
            $cnd1 = mysqli_query($link_connect,"select id from tuser where usertypeid='".Q($rsdel->id)."' ");
            if(mysqli_num_rows($cnd1)){
                $delrec=0;
                $msgerrname[]=$rsdel->label;
            }else{
                $delrec=1;
			    $msgsuccessnames[]=$rsdel->label;
            }
                // delete
                if ($delrec) {
                    mysqli_query($link_connect,"delete from tusertype where id ='".Q($ids_item)."'");
                    $msgsuccess="<b>".@implode(", ",$msgsuccessnames)."</b> Deleted Successfully";
                }else{
                    $msgerr="<b>".@implode(", ",$msgerrname)."</b> can't be deleted, Related to another data";
                }
			}
			
		}
	}
	
	endswitch;		
		
	switch ($showing):
		
	case "record":
	
	if(isset($msg) && $msg) {?>
	<div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div>
	<? }?>

	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" role="form" enctype="multipart/form-data">
	<div class="form-group">
		<label for="label">Label: <span class="text-danger">*</span></label>
		<input name="label" type="text" class="form-control" id="label" dir="ltr" value="<?=textencode($label)?>" />
    </div>
    <script type="text/javascript" src="plugins/tinymce/tinymce.min.js"></script>
	
    <div class="form-group">
		<label for="description">Description : </label>
		<script type="text/javascript">
            tinymce.init({
            selector: "textarea.description",
            theme: "modern",height: 300,
            directionality : 'ltr',
            cleanup_on_startup : true,
            force_br_newlines : false,
            force_p_newlines : false,
            forced_root_block : '',
            plugins: [
                "advlist autolink lists link image charmap preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "paste textcolor colorpicker textpattern responsivefilemanager"
            ],
            toolbar1: " undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
            toolbar2: "preview media | forecolor backcolor",
            image_advtab: true,
            paste_text_sticky : true,
            external_filemanager_path:"plugins/filemanager/",
            filemanager_title:"Photo / Video Manager" ,
            external_plugins: { "filemanager" : "../filemanager/plugin.min.js"},	
            oninit: function (ed) {
                ed.pasteAsPlainText = true;
            }
            });
        </script>
        <textarea name="description" id="description" class="description" style="width:100%;"><?=textencode($description)?></textarea>
    </div>

    <div class="form-group">
		<label for="rights">Rights : </label>
        <textarea name="rights" id="rights" class="rights" style="width:100%;height:200px;"><?=textencode($rights)?></textarea>
    </div>
            
                    
	<div><span class="text-danger">*</span> means Mandatory.</div>
	<div align="right">
	<input type="hidden" name="action" value="<?=$action?>exe">
	<input type="hidden" name="id" value="<?=isset($_REQUEST['id']) && $_REQUEST['id']?>">
	<button type="button" class="btn btn-danger" onClick="window.location='index.php?goto=<?=$_GET['goto']?>'"> <i class="glyphicon glyphicon-open"></i> Cancel</button>  <button type="submit" class="btn btn-primary pull-right" style="margin-left:4px;"> <i class="glyphicon glyphicon-save"></i> Save</button></div>
	</form>
	
	<div align="center">
	<a href="index.php?goto=<?=$_GET['goto']?>">Back To List</a>
	</div>
	<?	
	break;
	
	default:

	
	
	$cn=mysqli_query($link_connect,"select * from tusertype ".$qry." order by id asc");
	?>
	<? if (isset($msgerr) && $msgerr) {?>
	<div role="alert" class="alert alert-danger"><?=$msgerr?></div>
	<? }?>
	<? if (isset($msgsuccess) && $msgsuccess) {?>
	<div role="alert" class="alert alert-success"><?=$msgsuccess?></div>
	<? }?>
	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" name="del">
	<div id="toolbar" class="btn-group noprint">
	 <? if($_SESSION["admin_role"]=="SuperAdmin") { ?> <button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add'">
			<i class="glyphicon glyphicon-plus"></i> Add
		</button>
		<button type="button" class="btn btn-primary" onclick="conf()">
			<i class="glyphicon glyphicon-trash"></i> Delete
		</button><? } ?><button type="button" class="btn btn-success" onclick="window.location='pages/export_csv.php?table=tusertype&filename=<?=$_GET['goto']?>'">
        <i class="glyphicon glyphicon-export"></i> Export
    </button><button type="button" class="btn btn-success" onclick="window.print();">
        <i class="glyphicon glyphicon-print"></i> Print
    </button>
	</div>
	<table data-toggle="table" data-escape="false"  
    data-classes="table table-hover table-condensed"
	data-striped="true"
	data-cache="false"
	data-search="true"
	 data-show-refresh="true"
	data-show-toggle="true"
	data-show-columns="true"
	data-toolbar="#toolbar"
	data-pagination="true"
    data-page-list="[10,25,50,100,All]"
    data-page-size="25"	
    data-show-export="false"
    data-export-types="['csv', 'txt', 'excel']"data-state-save="false"
	data-state-save-id-table="tusertype" 	
	data-sort-name="id"
	data-sort-order="asc"	
	>
	<thead>
    <th><i class="glyphicon glyphicon-remove"></i></th>
	<th data-visible="false"  data-sortable="true"  data-field="id" data-halign="center"  data-align="left">ID</th>
	<th  data-sortable="true"  data-field="label" data-halign="center"  data-align="left">Label</th>
	<th data-field="description"  data-sortable="true" data-halign="center"  data-align="left"> Description </th>
	<th data-field="rights"  data-sortable="true" data-halign="center"  data-align="left"> Rights </th>
	<th>Action</th>
		
	</thead><tbody>
	<? while ($rs=mysqli_fetch_object($cn)) {?>
	<tr <? if (isset($_REQUEST['id']) && $rs->id==$_REQUEST['id']) {?> class="success" <? }?>>
		 <td><input type="checkbox" name="ids[]" value="<?=$rs->id?>"></td>
		<td><?=$rs->id?></td>
		<td dir="ltr"><?=$rs->label?></td>
        <td dir="ltr">
		<? if (preg_match_all('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/i',$rs->description, $result)) {
			    $vals=array("<br>","<br />","<p>","</p>","&nbsp;");
			    echo htmlentities(str_replace($vals,"",$rs->description));
			} else {
		        echo $rs->description;
			}?>
        </td>
        <td><?=$rs->rights?></td>
		<td><a href="index.php?goto=<?=$_GET['goto']?>&id=<?=$rs->id?>&action=edit" title="Edit"><i class="glyphicon glyphicon-edit"></i></a> </td>
		</tr>
		
	<? } ?>
	</tbody>
	</table> 
	<input type=hidden name="action" value="delete">
    </form>
	 	
	<script language="javascript">
        function conf(){
            if (confirm("Are you sure you want to delete this/these record(s)?")) {
                document.forms["del"].submit(); 
            }
        }
	</script>
	<? endswitch; ?>