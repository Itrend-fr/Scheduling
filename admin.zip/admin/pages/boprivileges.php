<? if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();}
$primhidden = '';
if (isset($_POST['button']) && $_POST['button']=='Update') {

		// updating
		$cn=mysqli_query($link_connect,"select * from bo_interface where active='Yes' and boid!='0' and boid!='9999' and (role='Admin' or role='User') ");
		while($rs=mysqli_fetch_object($cn)) {	
		
		mysqli_query($link_connect,"update bo_interface set role='".$_POST[$rs->id]."' where id='".$rs->id."'") Or die(mysqli_error($link_connect));
		}
		
		$msg='Changes Successfully Saved.'.$primhidden;
		$msgerr='success';	

}
?>
<? if(isset($msg) && $msg) {?><div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div><? }?>
<form name="form1" method="post" action="index.php?goto=<?=$_GET['goto']?>">
 <div class="table-responsive">
<table class="table table-striped">
<thead>
<th>Name</th>
<th>Privileges</th>
</thead>
<?
if($_SESSION['admin_role']=='SuperAdmin'){
	$query="select * from bo_interface where boid='0' and active='Yes' order by boid,pos";
}else{
	$query="select * from bo_interface where boid='0' and active='Yes' and (role='Admin' or role='User') order by boid,pos";
}
 $cn=mysqli_query($link_connect,$query);
	while($rs=mysqli_fetch_object($cn)) {
?>
<tr>
<td><strong><?=$rs->name?></strong></td>
<td>
</td>
</tr>

	<?
	if($_SESSION['admin_role']=='SuperAdmin'){
	$qry="select * from bo_interface where boid='".$rs->id."' and active='Yes' order by boid,pos";
	}else{
		$qry="select * from bo_interface where boid='".$rs->id."' and active='Yes' and (role='Admin' or role='User') order by boid,pos";
	}

     $cni=mysqli_query($link_connect,$qry);
        while($rsi=mysqli_fetch_object($cni)) {
    ?>
    <tr>
    <td style="padding-left:25px"><?=$rsi->name?>
    </td>
    <td>
    <select name="<?=$rsi->id?>" id="<?=$rsi->id?>">
    <option value="SuperAdmin" <? if ($rsi->role=='SuperAdmin') { ?> selected="selected"<? } ?>>Super Administrators</option>
    <option value="Admin" <? if ($rsi->role=='Admin') { ?> selected="selected"<? } ?>>Administrators</option>
    <option value="User" <? if ($rsi->role=='User') { ?> selected="selected"<? } ?>>Administrators & Moderators</option>
    </select>
    </td>
    </tr>
    <? }?>
<? } ?>

</table>
</div>
<div align="right" style="margin-bottom:5px;">
<input type="submit" name="button" id="button" value="Update" class="btn btn-primary">
</div>
</form>
