<? 
	if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();} 
	
	$action = isset($_REQUEST['action'])?$_REQUEST['action']:''; 
    $showing = $qry = '';
	switch ($action):
	
	// Add
	case "add":	
        $agendaid='';
		$consultationid='';
		$starttime='';
		$endtime='';
        $status='';
        $showing = "record";
	break;
	
	// Edit
	case "edit":
		$cn=mysqli_query($link_connect,"select * from agenda_consultation where appointmentid='".Q($_GET['appointmentid'])."'");
		$rs=mysqli_fetch_object($cn);
		$agendaid=$rs->agendaid;
						$consultationid=$rs->consultationid;
						$starttime=$rs->starttime;
						$endtime=$rs->endtime;
                        $status=$rs->status;
						
		$showing = "record";
	break;
	
	// Add or Edit Execution
	case "editexe":
	case "addexe":
	foreach($_SESSION['site_lang'] as $value) { }
		$agendaid=trime($_POST['agendaid']); 
	 $consultationid=trime($_POST['consultationid']); 
	 $starttime=trime($_POST['starttime']); 
	 $endtime=trime($_POST['endtime']);
     $status=trime($_POST['status']);  
     
	 
	 
	
	
		// Checking Conditions 
		 switch(true):case (!isset($_POST['csrf_token_'.$_GET['goto']]) || !$_SESSION['csrf_token_'.$_GET['goto']] || $_SESSION['csrf_token_'.$_GET['goto']] != $_POST['csrf_token_'.$_GET['goto']]): $msg="CSRF Token Verification Failed!"; break;case  !$agendaid: $msg="Agenda ID  is required and   should have a value selected."; break; 
		case  !$consultationid: $msg="Consultation ID  is required and   should have a value selected."; break; 
		case  !validateDate($starttime,"g:i A"): $msg="Start Time  is required and  should have a correct format LT (e.g. ".date("g:i A",strtotime("now")).")."; break; 
		case  !validateDate($endtime,"g:i A"): $msg="End Time  is required and  should have a correct format LT (e.g. ".date("g:i A",strtotime("now")).")."; break;
		case  !$status: $msg="Status  is required and   should have a value selected."; break; 
        endswitch;
	
		// If Conditions are fine
		if (!isset($msg) || $msg=="") {
		    $sqlqry="";
		
			$strSQL="agenda_consultation set 
				".$sqlqry."
		agendaid='".Q($agendaid)."',
			consultationid='".Q($consultationid)."',
			starttime='".Q(date("H:i:s",strtotime($starttime)))."',
			endtime='".Q(date("H:i:s",strtotime($endtime)))."',
			status='".Q($status)."'
			";
			
			if ($action=="editexe") {
			$strSQL ="update ".$strSQL." where appointmentid='".Q($_POST['appointmentid'])."'";
			} 
			if ($action=="addexe") {
			$strSQL ="insert into ".$strSQL;
			} 
				
			#echo $strSQL;
			mysqli_query($link_connect,"SET NAMES 'utf8'");
			mysqli_query($link_connect,$strSQL) or die(mysqli_error($link));
			
			unset($_SESSION['csrf_token_'.$_GET['goto']]);
		
		} else {
			$action = substr ($action,0,strlen($action)-3);
			$showing = "record";
			$msgerr="danger";
		}
		

		
	break;
	
	// Deleting Records
	case "delete":
	
	if (isset($_POST['ids']) && $_POST['ids']) {
		if(!isset($_POST['csrf_token_'.$_GET['goto'].'_del']) || !$_SESSION['csrf_token_'.$_GET['goto'].'_del'] || $_SESSION['csrf_token_'.$_GET['goto'].'_del'] != $_POST['csrf_token_'.$_GET['goto'].'_del']) {
			$msgerr="CSRF Token Validation Failed!";
		} else {
		
		foreach ($_POST['ids'] as $ids_item){
			
			$cndel=mysqli_query($link_connect,"select appointmentid,appointmentid from agenda_consultation where appointmentid ='".Q($ids_item)."'");
			if (mysqli_num_rows($cndel)) {
			$rsdel=mysqli_fetch_object($cndel);
			// delete
			$delrec=1;
			$msgsuccessnames[]=$rsdel->appointmentid;
			if ($delrec) {
		
				mysqli_query($link_connect,"delete from agenda_consultation where appointmentid ='".Q($ids_item)."'");
				$msgsuccess="<b>".@implode(", ",$msgsuccessnames)."</b> Deleted Successfully";
			}
			}
			
		}
	}
	
		unset($_SESSION['csrf_token_'.$_GET['goto'].'_del']);
		}
	endswitch;		
		
	switch ($showing):
		
	case "record":
	
	if(isset($msg) && $msg) {?>
	<div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div>
	<? }?>

	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" role="form" enctype="multipart/form-data">
	<div class="form-group">
				<label for="agendaid">Agenda: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.agendaid_filter_select2').select2();
			});
			</script>
			<select name="agendaid" id="agendaid" class="form-control agendaid_filter_select2" >
			<option value="" > - Select Agenda - </option>
			<? $cnrel=mysqli_query($link_connect,"select aid,aid from tagenda ".$qry." order by aid asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->aid?>" <? if($agendaid==$rsrel->aid) { echo " selected "; } ?>><?=$rsrel->aid?></option>
			<?	} ?>
			</select></div><div class="form-group">
				<label for="consultationid">Consultation: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.consultationid_filter_select2').select2();
			});
			</script>
			<select name="consultationid" id="consultationid" class="form-control consultationid_filter_select2" >
			<option value="" > - Select Consultation - </option>
			<? $cnrel=mysqli_query($link_connect,"select id,label from tconsultation ".$qry." order by id asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->id?>" <? if($consultationid==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
			<?	} ?>
			</select></div><div class="form-group">
				<label for="starttime">Start Time: <span class="text-danger">*</span></label>
				<div class="input-group date" id="date-starttime">
					<input name="starttime" type="text" class="form-control" id="starttime" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<? if ($starttime) {echo $starttime; }?>" />
					<span class="input-group-addon btn-success">
					<span class="glyphicon glyphicon-calendar"></span>
					</span>
					</div>
					<script type="text/javascript">
					$(function () {
						$('#date-starttime').datetimepicker({
							format: 'LT'	
						});
					});
					</script></div><div class="form-group">
				<label for="endtime">End Time: <span class="text-danger">*</span></label>
				<div class="input-group date" id="date-endtime">
					<input name="endtime" type="text" class="form-control" id="endtime" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<? if ($endtime) {echo $endtime; }?>" />
					<span class="input-group-addon btn-success">
					<span class="glyphicon glyphicon-calendar"></span>
					</span>
					</div>
					<script type="text/javascript">
					$(function () {
						$('#date-endtime').datetimepicker({
							format: 'LT'	
						});
					});
					</script></div>
                    <div class="form-group">
				<label for="status">Status: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.status_filter_select2').select2();
			});
			</script>
			<select name="status" id="status" class="form-control status_filter_select2" >
			<option value="" > - Select Status - </option>
			<? $cnrel=mysqli_query($link_connect,"select id,label from appointmentstatus ".$qry." order by label asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->id?>" <? if($status==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
			<?	} ?>
			</select></div>
	
	<div align="right">
	<input type="hidden" name="action" value="<?=$action?>exe">
	<input type="hidden" name="appointmentid" value="<?=isset($_REQUEST['appointmentid'])?$_REQUEST['appointmentid']:''?>">
	<button type="button" class="btn btn-danger" onClick="window.location='index.php?goto=<?=$_GET['goto']?>'"> <i class="glyphicon glyphicon-open"></i> Cancel</button>  <button type="submit" class="btn btn-primary pull-right" style="margin-left:4px;"> <i class="glyphicon glyphicon-save"></i> Save</button> </div>
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto']] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>" value="<?php echo $token; ?>">
	</form>
	
	<div align="center"  class="larecords">
	<a href="index.php?goto=<?=$_GET['goto']?>">List All Records</a>
	</div>
	<?	
	break;
	
	default:
	
	
	$cn=mysqli_query($link_connect,"select * from agenda_consultation ".$qry." order by appointmentid desc");
	
	
	
	?>
	<? if (isset($msgerr) &&  $msgerr) {?>
	<div role="alert" class="alert alert-danger"><?=$msgerr?></div>
	<? }?>
	<? if (isset($msgsuccess) && $msgsuccess) {?>
	<div role="alert" class="alert alert-success"><?=$msgsuccess?></div>
	<? }?>
	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" name="del">
	<div id="toolbar" class="btn-group noprint">
	<button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add'">
			<i class="glyphicon glyphicon-plus"></i> Add
		</button>
		<button type="button" class="btn btn-primary" onclick="conf()">
			<i class="glyphicon glyphicon-trash"></i> Delete
		</button><button type="button" class="btn btn-success" onclick="window.print();">
        <i class="glyphicon glyphicon-print"></i> Print
    </button>
	</div>
	<table 
	data-toggle="table" 
	data-escape="false"  
    data-classes="table table-hover table-condensed"
	data-striped="true"
	data-cache="false"
	data-show-footer="false"
	
		data-show-refresh="false"
		 data-search="true"
	 
	data-show-toggle="false"
	data-show-columns="true"
	data-toolbar="#toolbar"
	data-pagination="true"
    data-page-list="[10,25,50,100,All]"
    data-page-size="25"	
    data-show-export="true"
    data-export-types="['csv', 'txt', 'excel']"
	>
	<thead>
	<th class="text-center"><input type="checkbox" name="ids[]" onClick="toggle_checkbox(this)"></th>
			<th data-visible="false"  data-field="appointmentid" data-halign="center"  data-align="left">Appointment ID</th>
		<th  data-field="agendaid" data-halign="center"  data-align="left">Agenda <span class="text-danger">*</span> </th>
		<th  data-field="consultationid" data-halign="center"  data-align="left">Consultation <span class="text-danger">*</span> </th>
		<th  data-field="starttime" data-halign="center"  data-align="left">Start Time <span class="text-danger">*</span> </th>
		<th  data-field="endtime" data-halign="center"  data-align="left">End Time <span class="text-danger">*</span> </th>
		<th data-editable="true"  data-field="status" data-halign="center"  data-align="left">Status <span class="text-danger">*</span></th>
		<th data-field="action" data-halign="center"  data-align="left" data-editable="true">Action</th>
		
	</thead><tbody>
		<? while ($rs=mysqli_fetch_object($cn)) {?>
		<tr <? if (isset($_REQUEST['appointmentid']) && $rs->appointmentid==$_REQUEST['appointmentid']) {?> class="success" <? }?>>
		<td><input type="checkbox" name="ids[]" value="<?=$rs->appointmentid?>"></td>
			<td><?=$rs->appointmentid?></td>
				<td><?=getfield("tagenda","aid", "where aid='".Q($rs->agendaid)."' ")?></td>
					<td><?=getfield("tconsultation","label", "where id='".Q($rs->consultationid)."' ")?></td>
					<td ><?=date_disp("h:i A",$rs->starttime,'',$_SESSION["prim_lang"])?></td>
				<td ><?=date_disp("h:i A",$rs->endtime,'',$_SESSION["prim_lang"])?></td>
				<td>
				<?=getfield("appointmentstatus","label", "where id='".Q($rs->status)."'")?>
                </td>
                <td><a href="index.php?goto=<?=$_GET['goto']?>&appointmentid=<?=$rs->appointmentid?>&action=edit" title="Edit"><i class="glyphicon glyphicon-edit"></i></a> </td></tr>
		
		<? } ?>
	</tbody>
	</table>
	<input type=hidden name="action" value="delete">
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto'].'_del'] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>_del" value="<?php echo $token; ?>">	
	
	</form>
		
	
	<script language="javascript">
	function conf(){
		if (confirm("Are you sure you want to delete this/these record(s)?")) {
			document.forms["del"].submit(); 
		}
	}
	</script>
	<? endswitch; ?>