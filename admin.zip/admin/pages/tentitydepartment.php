<? 
	if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();} 
	$departmentid_filter=isset($_GET['departmentid_filter'])?$_GET['departmentid_filter']:'';
	$entityid_filter=isset($_GET['entityid_filter'])?$_GET['entityid_filter']:'';
			
	$action = isset($_REQUEST['action'])?$_REQUEST['action']:''; 
    $showing = $qry = "";
	switch ($action):
	
	// Add
	case "add":	
        $departmentid=''; 
	    $entityid='';
        $showing = "record";
	break;
	
	// Add or Edit Execution
	case "editexe":
	case "addexe":
	foreach($_SESSION['site_lang'] as $value) { }
		$departmentid=trime($_POST['departmentid']); 
	 $entityid=trime($_POST['entityid']); 
	
	
		// Checking Conditions 
		$use = getfield("entity_department","departmentid"," where departmentid='".Q($departmentid)."' and entityid='".Q($entityid)."'  ");

		 switch(true):
            case  !$departmentid: $msg="Le Departement est requis et doit avoir une valeur sélectionnée."; break; 
			case  !$entityid: $msg="L'entité est obligatoire et doit avoir une valeur sélectionnée."; break;
			case $use: $msg="L'entité dispose de ce Departement."; break;
		 endswitch;
	
		// If Conditions are fine
		if (!isset($msg) || $msg=="") {
		    $sqlqry="";
		
			$strSQL="entity_department set 
				".$sqlqry."
		departmentid='".Q($departmentid)."',
			entityid='".Q($entityid)."'
			";
			
			
			if ($action=="addexe") {
			$strSQL ="insert into ".$strSQL;
			} 
				
			#echo $strSQL;
			mysqli_query($link_connect,"SET NAMES 'utf8'");
			mysqli_query($link_connect,$strSQL) or die(mysqli_error($link_connect));
			
			unset($_SESSION['csrf_token_'.$_GET['goto']]);
			
			
		
		} else {
			$action = substr ($action,0,strlen($action)-3);
			$showing = "record";
			$msgerr="danger";
		}
		

		
	break;
	
	// Deleting Records
	case "delete":
	
	if (isset($_POST['ids']) && $_POST['ids']) {
		if(!isset($_POST['csrf_token_'.$_GET['goto'].'_del']) || !$_SESSION['csrf_token_'.$_GET['goto'].'_del'] || $_SESSION['csrf_token_'.$_GET['goto'].'_del'] != $_POST['csrf_token_'.$_GET['goto'].'_del']) {
			$msgerr="CSRF Token Validation Failed!";
		} else {
		
		foreach ($_POST['ids'] as $ids_item){
			$dids = explode('_',$ids_item);
			//print_r($dids);
			$cndel=mysqli_query($link_connect,"select * from entity_department where departmentid ='".Q($dids[0])."' and entityid='".Q($dids[1])."' ");
			if (mysqli_num_rows($cndel)) {
			$rsdel=mysqli_fetch_object($cndel);
			// delete
			$delrec=1;
			$msgsuccessnames[] = '';
			//$msgsuccessnames[]=$rsdel->id;
			if ($delrec) {
		
				mysqli_query($link_connect,"delete from entity_department where departmentid ='".Q($dids[0])."' and entityid='".Q($dids[1])."'");
				$msgsuccess="<b>".@implode(", ",$msgsuccessnames)."</b> Deleted Successfully";
			}
			}
			
		}
	}
	
		unset($_SESSION['csrf_token_'.$_GET['goto'].'_del']);
		}
	endswitch;		
		
	switch ($showing):
		
	case "record":
	
	if(isset($msg) && $msg) {?>
	<div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div>
	<? }?>

	<form action="index.php?goto=<?=$_GET['goto']?>&departmentid_filter=<?=$departmentid_filter?>&entityid_filter=<?=$entityid_filter?>" method="post" role="form" enctype="multipart/form-data">
	<div class="form-group">
				<label for="departmentid">Department: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.departmentid_filter_select2').select2();
			});
			</script>
			<select name="departmentid" id="departmentid" class="form-control departmentid_filter_select2" >
			<option value="" > - Select Department - </option>
			<? $cnrel=mysqli_query($link_connect,"select id,label from tdepartment ".$qry." order by label asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->id?>" <? if($departmentid==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
			<?	} ?>
			</select></div><div class="form-group">
				<label for="entityid">Entity: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.entityid_filter_select2').select2();
			});
			</script>
			<select name="entityid" id="entityid" class="form-control entityid_filter_select2" >
			<option value="" > - Select Entity - </option>
			<? $cnrel=mysqli_query($link_connect,"select eid,efirstname from tentity ".$qry." order by efirstname asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->eid?>" <? if($entityid==$rsrel->eid) { echo " selected "; } ?>><?=$rsrel->efirstname?></option>
			<?	} ?>
			</select></div>
	
	<div align="right">
	<input type="hidden" name="action" value="<?=$action?>exe">
	<button type="button" class="btn btn-danger" onClick="window.location='index.php?goto=<?=$_GET['goto']?>&departmentid_filter=<?=$departmentid_filter?>&entityid_filter=<?=$entityid_filter?>'"> <i class="glyphicon glyphicon-open"></i> Cancel</button>  <button type="submit" class="btn btn-primary pull-right" style="margin-left:4px;"> <i class="glyphicon glyphicon-save"></i> Save</button> </div>
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto']] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>" value="<?php echo $token; ?>">
	</form>
	
	<div align="center"  class="larecords">
	<a href="index.php?goto=<?=$_GET['goto']?>&departmentid_filter=<?=$departmentid_filter?>&entityid_filter=<?=$entityid_filter?>">List All Records</a>
	</div>
	<?	
	break;
	
	default:
	 if ($departmentid_filter) {
				
				$qry.=" departmentid='".Q($departmentid_filter)."'";
				 }
			 if ($entityid_filter) {
				if ($qry) { $qry.=" and "; } 
				$qry.=" entityid='".Q($entityid_filter)."'";
				 }
			 if ($qry) { $qry=" where ".$qry; }
	
	$cn=mysqli_query($link_connect,"select * from entity_department ".$qry."");
	
	
	
	?>
	<? if (isset($msgerr) && $msgerr) {?>
	<div role="alert" class="alert alert-danger"><?=$msgerr?></div>
	<? }?>
	<? if (isset($msgsuccess) && $msgsuccess) {?>
	<div role="alert" class="alert alert-success"><?=$msgsuccess?></div>
	<? }?>
	<form action="index.php?goto=<?=$_GET['goto']?>&departmentid_filter=<?=$departmentid_filter?>&entityid_filter=<?=$entityid_filter?>" method="post" name="del">
	<div>
		<label>Filter:</label>
		<div class="col-md-12" style="padding:0px !important"><div class="col-md-3" style="padding:0px 10px 0px 0px !important">
			
		<script>
		$(document).ready(function() {
			$('.departmentid_filter_select2').select2();
		});
		</script>
		<select name="departmentid_filter" id="departmentid_filter" onchange="if (this.value) window.location.href=this.value" class="form-control departmentid_filter_select2">
		<option value="index.php?goto=<?=$_GET['goto']?>&entityid_filter=<?=$entityid_filter?>" > - All Departments - </option><? 
			if($qryfilter){$qryfilter=" where ".$qryfilter;}
			$qfrelation=mysqli_query($link_connect,"select * from tdepartment ".$qryfilter." order by 'label".$_SESSION['prim_lang']."'") or die(mysqli_error($link));
			if(mysqli_num_rows($qfrelation)){
				while($rsfrealtion=mysqli_fetch_object($qfrelation)){?><option value="index.php?goto=<?=$_GET['goto']?>&entityid_filter=<?=$entityid_filter?>&departmentid_filter=<?=$rsfrealtion->id?>" <? if($departmentid_filter==$rsfrealtion->id) { echo " selected "; } ?> ><?=$rsfrealtion->label?></option>;	
			<?	}
			} ?></select>
			</div><div class="col-md-3" style="padding:0px 10px 0px 0px !important">
			
		<script>
		$(document).ready(function() {
			$('.entityid_filter_select2').select2();
		});
		</script>
		<select name="entityid_filter" id="entityid_filter" onchange="if (this.value) window.location.href=this.value" class="form-control entityid_filter_select2">
		<option value="index.php?goto=<?=$_GET['goto']?>&departmentid_filter=<?=$departmentid_filter?>" > - All Entity - </option><? 
			if($qryfilter){$qryfilter=" where ".$qryfilter;}
			$qfrelation=mysqli_query($link_connect,"select * from tentity ".$qryfilter." order by 'efirstname".$_SESSION['prim_lang']."'") or die(mysqli_error($link));
			if(mysqli_num_rows($qfrelation)){
				while($rsfrealtion=mysqli_fetch_object($qfrelation)){?><option value="index.php?goto=<?=$_GET['goto']?>&departmentid_filter=<?=$departmentid_filter?>&entityid_filter=<?=$rsfrealtion->eid?>" <? if($entityid_filter==$rsfrealtion->eid) { echo " selected "; } ?> ><?=$rsfrealtion->efirstname?></option>;	
			<?	}
			} ?></select>
			</div></div>
		</div>
		<div id="toolbar" class="btn-group noprint">
	<button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add&departmentid_filter=<?=$departmentid_filter?>&entityid_filter=<?=$entityid_filter?>'">
			<i class="glyphicon glyphicon-plus"></i> Add
		</button>
		<button type="button" class="btn btn-primary" onclick="conf()">
			<i class="glyphicon glyphicon-trash"></i> Delete
		</button><button type="button" class="btn btn-success" onclick="window.print();">
        <i class="glyphicon glyphicon-print"></i> Print
    </button>
	</div>
	<table 
	data-toggle="table" 
	data-escape="false"  
    data-classes="table table-hover table-condensed"
	data-striped="true"
	data-cache="false"
	data-show-footer="false"
	
		data-show-refresh="false"
		 data-search="true"
	 
	data-show-toggle="false"
	data-show-columns="true"
	data-toolbar="#toolbar"
	data-pagination="true"
    data-page-list="[10,25,50,100,All]"
    data-page-size="25"	
    data-show-export="true"
    data-export-types="['csv', 'txt', 'excel']"
	>
	<thead>
	<th class="text-center"><input type="checkbox" name="ids[]" onClick="toggle_checkbox(this)"></th>
		<th  data-field="departmentid" data-halign="center"  data-align="left">Department <span class="text-danger">*</span> </th>
		<th data-field="entityid" data-halign="center"  data-align="left">Entity <span class="text-danger">*</span> </th>
		
	</thead><tbody>
		<? while ($rs=mysqli_fetch_object($cn)) {?>
		<tr>
		<td><input type="checkbox" name="ids[]" value="<?=$rs->departmentid?>_<?=$rs->entityid?>"></td>
				<td><?=getfield("tdepartment","label", "where id='".Q($rs->departmentid)."' ")?></td>
					<td><?=getfield("tentity","efirstname", " where eid='".Q($rs->entityid)."'")?></td>
		</tr>
		
		<? } ?>
	</tbody>
	</table>
	<input type=hidden name="action" value="delete">
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto'].'_del'] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>_del" value="<?php echo $token; ?>">	
	
	</form>
		
	
	<script language="javascript">
	function conf(){
		if (confirm("Are you sure you want to delete this/these record(s)?")) {
			document.forms["del"].submit(); 
		}
	}
	</script>
	<? endswitch; ?>