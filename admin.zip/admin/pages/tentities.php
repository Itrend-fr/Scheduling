<? 
	if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();} 
	
	$action = isset($_REQUEST['action'])?$_REQUEST['action']:''; 
    $showing = "";
    $qry = "";
	switch ($action):
	
	// Add
	case "add":	
        $efirstname='';
        $elastname='';
		$egender='';
		$eemail='';
		$etel='';
		$eaddr='';
		$epostcode='';
		$ecity='';
		$ecountry='';
		$gradyear='';
		$practice='';
		$specialty='';
		$lang='';
		$detail='';
        $luid='';
        $showing = "record";
	break;
	
	// Edit
	case "edit":
		$cn=mysqli_query($link_connect,"select * from tentity where eid='".Q($_GET['eid'])."'");
		$rs=mysqli_fetch_object($cn);
		$efirstname=$rs->efirstname;
						$elastname=$rs->elastname;
						$egender=$rs->egender;
						$eemail=$rs->eemail;
						$etel=$rs->etel;
						$eaddr=$rs->eaddr;
						$epostcode=$rs->epostcode;
						$ecity=$rs->ecity;
						$ecountry=$rs->ecountry;
						$gradyear=$rs->gradyear;
						$practice=$rs->practice;
						$specialty=$rs->specialty;
						$lang=$rs->lang;
						$detail=$rs->detail;
                        $luid=$rs->luid;
						
		$showing = "record";
	break;
	
	// Add or Edit Execution
	case "editexe":
	case "addexe":
	foreach($_SESSION['site_lang'] as $value) { }
		$efirstname=trime($_POST['efirstname']); 
	 $elastname=trime($_POST['elastname']); 
	 $egender=trime($_POST['egender']); 
	 $eemail=trime($_POST['eemail']); 
	 $etel=trime($_POST['etel']); 
	 $eaddr=trime($_POST['eaddr']); 
	 $epostcode=trime($_POST['epostcode']); 
	 $ecity=trime($_POST['ecity']); 
	 $ecountry=trime($_POST['ecountry']); 
	 $gradyear=trime($_POST['gradyear']); 
	 $practice=trime($_POST['practice']); 
	 $specialty=trime($_POST['specialty']); 
	 $lang=trime($_POST['lang']); 
	 $detail=trime($_POST['detail']); 
	 $luid=trime($_POST['luid']); 
	
		// Checking Conditions 
		 switch(true):case (!isset($_POST['csrf_token_'.$_GET['goto']]) || !$_SESSION['csrf_token_'.$_GET['goto']] || $_SESSION['csrf_token_'.$_GET['goto']] != $_POST['csrf_token_'.$_GET['goto']]): $msg="CSRF Token Verification Failed!"; break;case  !$efirstname: $msg="First Name  is required and  cannot be empty."; break; 
		case  !$elastname: $msg="Last Name  is required and  cannot be empty."; break; 
		case  !$egender: $msg="Gender  is required and  cannot be empty."; break; 
		case  !isemail($eemail): $msg="Email  is required and  should be a valid Email Address."; break; 
		case $etel &&  !validatePhone($etel): $msg="Telephone  is required and  should have a correct format (e.g. 9613000000)."; break; 
		case $epostcode &&  !$epostcode: $msg="Postcode  is required and  cannot be empty."; break; 
		case $ecity &&  !$ecity: $msg="City  is required and  cannot be empty."; break; 
		case $ecountry &&  !$ecountry: $msg="Country  is required and  cannot be empty."; break; 
		case  !validateDate($gradyear,"Y"): $msg="Grad Year  is required and  should have a correct format YYYY (e.g. ".date("Y",strtotime("now")).")."; break; 
		case $practice &&  !$practice: $msg="Practice  is required and  cannot be empty."; break; 
		case $specialty &&  !$specialty: $msg="Specialty  is required and  cannot be empty."; break; 
		case $lang &&  !$lang: $msg="Lang  is required and  cannot be empty."; break;
        case  !$luid: $msg="User  is required and   should have a value selected."; break;
		 endswitch;
	
		// If Conditions are fine
		if (!isset($msg) || $msg=="") {
		    $sqlqry="";
		
			$strSQL="tentity set 
				".$sqlqry."
		efirstname='".Q($efirstname)."',
			elastname='".Q($elastname)."',
			egender='".Q($egender)."',
			eemail='".Q($eemail)."',
			etel='".Q($etel)."',
			eaddr='".Q($eaddr)."',
			epostcode='".Q($epostcode)."',
			ecity='".Q($ecity)."',
			ecountry='".Q($ecountry)."',
			gradyear='".Q($gradyear)."',
			practice='".Q($practice)."',
			specialty='".Q($specialty)."',
			lang='".Q($lang)."',
			detail='".Q($detail)."',
			luid='".Q($luid)."'
			";
			
			if ($action=="editexe") {
			$strSQL ="update ".$strSQL." where eid='".Q($_POST['eid'])."'";
			} 
			if ($action=="addexe") {
			$strSQL ="insert into ".$strSQL;
			} 
				
			#echo $strSQL;
			mysqli_query($link_connect,"SET NAMES 'utf8'");
			mysqli_query($link_connect,$strSQL) or die(mysqli_error($link));
			
			unset($_SESSION['csrf_token_'.$_GET['goto']]);
		
		} else {
			$action = substr ($action,0,strlen($action)-3);
			$showing = "record";
			$msgerr="danger";
		}
		

		
	break;
	
	// Deleting Records
	case "delete":
	
	if (isset($_POST['ids']) && $_POST['ids']) {
		if(!isset($_POST['csrf_token_'.$_GET['goto'].'_del']) || !$_SESSION['csrf_token_'.$_GET['goto'].'_del'] || $_SESSION['csrf_token_'.$_GET['goto'].'_del'] != $_POST['csrf_token_'.$_GET['goto'].'_del']) {
			$msgerr="CSRF Token Validation Failed!";
		} else {
		
		foreach ($_POST['ids'] as $ids_item){
			
			$cndel=mysqli_query($link_connect,"select eid,efirstname from tentity where eid ='".Q($ids_item)."'");
			if (mysqli_num_rows($cndel)) {
			$rsdel=mysqli_fetch_object($cndel);
			// delete
			$delrec=1;
			$msgsuccessnames[]=$rsdel->efirstname;
			if ($delrec) {
		
				mysqli_query($link_connect,"delete from tentity where eid ='".Q($ids_item)."'");
				$msgsuccess="<b>".@implode(", ",$msgsuccessnames)."</b> Deleted Successfully";
			}
			}
			
		}
	}
	
		unset($_SESSION['csrf_token_'.$_GET['goto'].'_del']);
		}
	endswitch;		
		
	switch ($showing):
		
	case "record":
	
	if(isset($msg) && $msg) {?>
	<div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div>
	<? }?>

	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" role="form" enctype="multipart/form-data">
	<div class="form-group">
				<label for="efirstname">First Name: <span class="text-danger">*</span></label>
				<input name="efirstname" type="text" class="form-control" id="efirstname" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($efirstname)?>" /></div><div class="form-group">
				<label for="elastname">Last Name: <span class="text-danger">*</span></label>
				<input name="elastname" type="text" class="form-control" id="elastname" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($elastname)?>" /></div>
				<div class="form-group">
					<label for="egender">Gender: <span class="text-danger">*</span></label>
					<script>
				$(document).ready(function() {
					$('.egender_filter_select2').select2();
				});
				</script>
				<select name="egender" id="egender" class="form-control egender_filter_select2" >
				<option value="" > - Select Gender - </option>
				<? $cnrel=mysqli_query($link_connect,"select id,text_en from tgender ".$qry." order by text_".$_SESSION['prim_lang']." asc");
				while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
				<option value="<?=$rsrel->id?>" <? if($egender==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->{"text_en"}?></option>
				<?	} ?>
				</select></div>
				<div class="form-group">
				<label for="eemail">Email: <span class="text-danger">*</span></label>
				<input name="eemail" type="email" class="form-control" id="eemail" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($eemail)?>" /></div><div class="form-group">
				<label for="etel">Telephone: </label>
				<input name="etel" type="text" class="form-control" id="etel" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($etel)?>" /><div><small class="text-warning"><em>Use only numeric values.</em></small></div></div><script type="text/javascript" src="plugins/tinymce/tinymce.min.js"></script>
			<div class="form-group">
				<label for="eaddr">Address: </label>
				<script type="text/javascript">
	tinymce.init({
    selector: "textarea.eaddr",
    themes: "modern",
	height: 300,
	directionality : 'ltr',
	cleanup_on_startup : true,
	force_br_newlines : false,
      force_p_newlines : false,
      forced_root_block : '',
    plugins: [
        "advlist autolink lists link image charmap preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code",
        "insertdatetime media nonbreaking save table contextmenu directionality",
        "paste textcolor colorpicker textpattern responsivefilemanager"
    ],
    toolbar1: " undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    toolbar2: "preview media | forecolor backcolor",
    image_advtab: true,
	paste_text_sticky : true,
	external_filemanager_path:"plugins/filemanager/",
	filemanager_title:"Photo / Video Manager" ,
	external_plugins: { "filemanager" : "../filemanager/plugin.min.js"},	
	oninit: function (ed) {
        ed.pasteAsPlainText = true;
    }
});
</script>
<textarea name="eaddr" id="eaddr" class="eaddr" style="width:100%;"><?=textencode($eaddr)?></textarea></div><div class="form-group">
				<label for="epostcode">Postcode: </label>
				<input name="epostcode" type="text" class="form-control" id="epostcode" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($epostcode)?>" /></div>
                <div class="form-group">
				<label for="ecountry">Country: </label>
				<script>
                $(document).ready(function() {
                    $('.ecountry_filter_select2').select2();
                });
                </script>
                <select name="ecountry" id="ecountry" class="form-control ecountry_filter_select2" >
                <option value="" > - Select Country - </option>
                <? $cnrel=mysqli_query($link_connect,"select id,label from tcountry ".$qry." order by id asc");
                while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
                <option value="<?=$rsrel->id?>" <? if($ecountry==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
                <?	} ?>
                </select>
                </div>
                <div class="form-group">
				<label for="ecity">City: </label>
				<input name="ecity" type="text" class="form-control" id="ecity" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($ecity)?>" /></div>
                
                <div class="form-group">
				<label for="gradyear">Grad Year: <span class="text-danger">*</span></label>
				<div class="input-group date" id="date-gradyear">
					<input name="gradyear" type="text" class="form-control" id="gradyear" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<? if ($gradyear) {echo $gradyear; }?>" />
					<span class="input-group-addon btn-success">
					<span class="glyphicon glyphicon-calendar"></span>
					</span>
					</div>
					<script type="text/javascript">
					$(function () {
						$('#date-gradyear').datetimepicker({
							format: 'YYYY'	
						});
					});
					</script></div><div class="form-group">
				<label for="practice">Practice: </label>
				<input name="practice" type="text" class="form-control" id="practice" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($practice)?>" /></div><div class="form-group">
				<label for="specialty">Specialty: </label>
				<input name="specialty" type="text" class="form-control" id="specialty" dir="<?=$_SESSION['site_lang'][0]['direction']?>" value="<?=textencode($specialty)?>" /></div>
                <div class="form-group">
				<label for="lang">Lang: </label>
				<script>
                $(document).ready(function() {
                    $('.lang_filter_select2').select2();
                });
                </script>
                <select name="lang" id="lang" class="form-control lang_filter_select2" >
                <option value="" > - Select Lang - </option>
                <? $cnrel=mysqli_query($link_connect,"select id,label from tlanguage ".$qry." order by id asc");
                while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
                <option value="<?=$rsrel->id?>" <? if($lang==$rsrel->id) { echo " selected "; } ?>><?=$rsrel->label?></option>
                <?	} ?>
                </select></div>
                <div class="form-group">
				<label for="detail">Detail: </label>
				<script type="text/javascript">
	tinymce.init({
    selector: "textarea.detail",
    themes: "modern",
	height: 300,
	directionality : '<?=$_SESSION['site_lang'][0]['direction']?>',
	cleanup_on_startup : true,
	force_br_newlines : false,
      force_p_newlines : false,
      forced_root_block : '',
    plugins: [
        "advlist autolink lists link image charmap preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code",
        "insertdatetime media nonbreaking save table contextmenu directionality",
        "paste textcolor colorpicker textpattern responsivefilemanager"
    ],
    toolbar1: " undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    toolbar2: "preview media | forecolor backcolor",
    image_advtab: true,
	paste_text_sticky : true,
	external_filemanager_path:"plugins/filemanager/",
	filemanager_title:"Photo / Video Manager" ,
	external_plugins: { "filemanager" : "../filemanager/plugin.min.js"},	
	oninit: function (ed) {
        ed.pasteAsPlainText = true;
    }
});
</script>
<textarea name="detail" id="detail" class="detail" style="width:100%;"><?=textencode($detail)?></textarea></div>
	
<div class="form-group">
				<label for="luid">User: <span class="text-danger">*</span></label>
				<script>
			$(document).ready(function() {
				$('.luid_filter_select2').select2();
			});
			</script>
			<select name="luid" id="luid" class="form-control luid_filter_select2" >
			<option value="" > - Select User - </option>
			<? $cnrel=mysqli_query($link_connect,"select uid,login from tuser order by login asc");
			while ($rsrel=mysqli_fetch_object($cnrel)) { ?>
			<option value="<?=$rsrel->uid?>" <? if($luid==$rsrel->uid) { echo " selected "; } ?>><?=$rsrel->login?></option>
			<?	} ?>
			</select></div>

	<div align="right">
	<input type="hidden" name="action" value="<?=$action?>exe">
	<input type="hidden" name="eid" value="<?=isset($_REQUEST['eid'])?$_REQUEST['eid']:''?>">
	<button type="button" class="btn btn-danger" onClick="window.location='index.php?goto=<?=$_GET['goto']?>'"> <i class="glyphicon glyphicon-open"></i> Cancel</button>  <button type="submit" class="btn btn-primary pull-right" style="margin-left:4px;"> <i class="glyphicon glyphicon-save"></i> Save</button> </div>
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto']] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>" value="<?php echo $token; ?>">
	</form>
	
	<div align="center"  class="larecords">
	<a href="index.php?goto=<?=$_GET['goto']?>">List All Records</a>
	</div>
	<?	
	break;
	
	default:
	
	
	$cn=mysqli_query($link_connect,"select * from tentity ".$qry." order by eid desc");
	
	
	
	?>
	<? if (isset($msgerr) && $msgerr) {?>
	<div role="alert" class="alert alert-danger"><?=$msgerr?></div>
	<? }?>
	<? if (isset($msgsuccess) && $msgsuccess) {?>
	<div role="alert" class="alert alert-success"><?=$msgsuccess?></div>
	<? }?>
	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" name="del">
	<div id="toolbar" class="btn-group noprint">
	<button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add'">
			<i class="glyphicon glyphicon-plus"></i> Add
		</button>
		<button type="button" class="btn btn-primary" onclick="conf()">
			<i class="glyphicon glyphicon-trash"></i> Delete
		</button><button type="button" class="btn btn-success" onclick="window.print();">
        <i class="glyphicon glyphicon-print"></i> Print
    </button>
	</div>
	<table 
	data-toggle="table" 
	data-escape="false"  
    data-classes="table table-hover table-condensed"
	data-striped="true"
	data-cache="false"
	data-show-footer="false"
	
		data-show-refresh="false"
		 data-search="true"
	 
	data-show-toggle="false"
	data-show-columns="true"
	data-toolbar="#toolbar"
	data-pagination="true"
    data-page-list="[10,25,50,100,All]"
    data-page-size="25"	
    data-show-export="true"
    data-export-types="['csv', 'txt', 'excel']"
	>
	<thead>
	<th class="text-center"><input type="checkbox" name="ids[]" onClick="toggle_checkbox(this)"></th>
			<th data-visible="false"  data-field="eid" data-halign="center"  data-align="left">Eid</th>
		<th  data-field="efirstname" data-halign="center"  data-align="left">First Name <span class="text-danger">*</span> </th>
		<th  data-field="elastname" data-halign="center"  data-align="left">Last Name <span class="text-danger">*</span> </th>
		<th  data-field="egender" data-halign="center"  data-align="left">Gender <span class="text-danger">*</span> </th>
		<th data-visible="false"  data-field="eemail" data-halign="center"  data-align="left">Email <span class="text-danger">*</span> </th>
		<th data-visible="false"  data-field="etel" data-halign="center"  data-align="left">Telephone</th>
		<th data-visible="false"  data-field="eaddr" data-halign="center"  data-align="left">Address</th>
		<th data-visible="false"  data-field="epostcode" data-halign="center"  data-align="left">Postcode</th>
		<th data-visible="false"  data-field="ecity" data-halign="center"  data-align="left">City</th>
		<th data-visible="false"  data-field="ecountry" data-halign="center"  data-align="left">Country</th>
		<th data-visible="false"  data-field="gradyear" data-halign="center"  data-align="left">Grad Year <span class="text-danger">*</span> </th>
		<th data-visible="false"  data-field="practice" data-halign="center"  data-align="left">Practice</th>
		<th data-visible="false"  data-field="specialty" data-halign="center"  data-align="left">Specialty</th>
		<th data-visible="false"  data-field="lang" data-halign="center"  data-align="left">Lang</th>
		<th data-visible="false"  data-field="detail" data-halign="center"  data-align="left">Detail</th>
		<th data-visible="false"  data-field="edatep" data-halign="center"  data-align="left">Date P</th>
		<th data-visible="false"  data-field="edatec" data-halign="center"  data-align="left">Date Created</th>
		<th data-visible="false"  data-field="edatem" data-halign="center"  data-align="left">Date Modify</th>
		<th data-visible="false"  data-field="euidm" data-halign="center"  data-align="left">UID Modify</th>
		<th data-field="luid" data-halign="center"  data-align="left">User</th>
		<th data-field="action" data-halign="center"  data-align="left" data-editable="true">Action</th>
		
	</thead><tbody>
		<? while ($rs=mysqli_fetch_object($cn)) {?>
		<tr <? if (isset($_REQUEST['eid']) && $rs->eid==$_REQUEST['eid']) {?> class="success" <? }?>>
		<td><input type="checkbox" name="ids[]" value="<?=$rs->eid?>"></td>
			<td><?=$rs->eid?></td>
				<td ><?=$rs->efirstname?></td>
				<td ><?=$rs->elastname?></td>
				<td ><?=getfield("tgender","text_en", " where id='".Q($rs->egender)."'")?></td>
				<td ><a href="mailto:<?=$rs->eemail?>"><?=$rs->eemail?></a></td>
				<td ><?=$rs->etel?></td>
				<td ><?=strip_tags($rs->eaddr,'<img><p><b><em><strong><a><i><u><ul><ol><li><br><br />')?></td>
				<td ><?=$rs->epostcode?></td>
				<td ><?=$rs->ecity?></td>
				<td ><?=getfield("tcountry","label", "where id='".Q($rs->ecountry)."'")?></td>
				<td ><?=date_disp("Y",$rs->gradyear,'',$_SESSION["prim_lang"])?></td>
				<td ><?=$rs->practice?></td>
				<td ><?=$rs->specialty?></td>
				<td ><?=getfield("tlanguage","label", "where id='".Q($rs->lang)."'")?></td>
				<td ><?=strip_tags($rs->detail,'<img><p><b><em><strong><a><i><u><ul><ol><li><br><br />')?></td>
				<td ><?=date_disp("D, d M Y h:i A",$rs->edatep,'',$_SESSION["prim_lang"])?></td>
				<td ><?=date_disp("D, d M Y h:i A",$rs->edatec,'',$_SESSION["prim_lang"])?></td>
				<td ><?=date_disp("D, d M Y h:i A",$rs->edatem,'',$_SESSION["prim_lang"])?></td>
				<td><?=getfield("tuser","login", " where uid='".Q($rs->puidm)."'")?></td>
				<td><?=getfield("tuser","login", " where uid='".Q($rs->luid)."'")?></td>
				
                <td><a href="index.php?goto=<?=$_GET['goto']?>&eid=<?=$rs->eid?>&action=edit" title="Edit"><i class="glyphicon glyphicon-edit"></i></a> </td></tr>
		
		<? } ?>
	</tbody>
	</table>
	<input type=hidden name="action" value="delete">
	<?
	$token = md5(uniqid(rand(), TRUE));
	$_SESSION['csrf_token_'.$_GET['goto'].'_del'] = $token;			 
	?>
	<input type="hidden" name="csrf_token_<?=$_GET['goto']?>_del" value="<?php echo $token; ?>">	
	
	</form>
		
	
	<script language="javascript">
	function conf(){
		if (confirm("Are you sure you want to delete this/these record(s)?")) {
			document.forms["del"].submit(); 
		}
	}
	</script>
	<? endswitch; ?>