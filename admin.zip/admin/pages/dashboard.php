<? if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();} ?>
  
 

<div class="">
  <h2>Beinvenue <?=$_SESSION['admin_name']?>!</h2>
</div>



 