<? if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();}
	
	$action = isset($_REQUEST['action'])?$_REQUEST['action']:''; 
	$showing = $qry = "";
	switch ($action):
	
	// Add
	case "add": if($_SESSION["admin_role"]=="SuperAdmin") { 
		$name='';
		
		$showing = "record";
	}
	break;
	
	// Edit
	case "edit":
		$cn=mysqli_query($link_connect,"select * from users where id='".Q($_GET['id'])."'");
		$rs=mysqli_fetch_object($cn);
		$name=$rs->name;
		
		
		$showing = "record";
	break;
	
	// Add or Edit Execution
	case "editexe":
	case "addexe":
	$name=trime($_POST['name']);
	

		// Checking Conditions
		
		/*$descrerr='';
			foreach($_SESSION['site_lang'] as $value) {
				if (!${$value}) { $descrerr='true'; }
		}
		*/		
		switch(true):
		case !$name: $msg="Name cannot be empty."; break;
		//case $descrerr: $msg="Content ".strtoupper(implode(" & ",$_SESSION['site_lang']))." cannot be empty."; break;
			
		endswitch;
	
		// If Conditions are fine
		if (!isset($msg) || $msg=="") {
			
			$sqlqry='';
			
						
			$strSQL="users set 
			".$sqlqry."
			name='".Q($name)."'
			";
			
			if ($action=="editexe") {
			$strSQL ="update ".$strSQL." where id='".Q($_POST['id'])."'";
			}  if($_SESSION["admin_role"]=="SuperAdmin") { 
			if ($action=="addexe") {
			$strSQL ="insert into ".$strSQL;
			} 
			 } 	
			 
			#echo $strSQL;
			mysqli_query($link_connect,"SET NAMES 'utf8'");
			mysqli_query($link_connect,$strSQL);
			
		
		
		} else {
			$action = substr ($action,0,strlen($action)-3);
			$showing = "record";
			$msgerr="danger";
		}
		

		
	break;
	
	// Deleting Records
	case "delete":
	
	if (isset($_POST['ids']) && $_POST['ids']) {
		foreach ($_POST['ids'] as $ids_item){
			
			$cndel=mysqli_query($link_connect,"select id,name from users where id ='".Q($ids_item)."'");
			if (mysqli_num_rows($cndel)) {
			$rsdel=mysqli_fetch_object($cndel);
			// delete
			$delrec=1;
			$msgsuccessnames[]=$rsdel->name;
			if ($delrec) {
		
		mysqli_query($link_connect,"delete from scheduling where id ='".Q($ids_item)."'");
				$msgsuccess="<b>".@implode(", ",$msgsuccessnames)."</b> Deleted Successfully";
			}
			}
			
		}
	}
	
	endswitch;		
		
	switch ($showing):
		
	case "record":
	
	if(isset($msg) && $msg) {?>
	<div class="alert alert-<?=$msgerr?>" role="alert"><?=$msg?></div>
	<? }?>

	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" role="form" enctype="multipart/form-data">
	<div class="form-group">
				<label for="name">Name: <span class="text-danger">*</span></label>
				<input name="name" type="text" class="form-control" id="name" dir="ltr" value="<?=textencode($name)?>" />
            </div>
                    
	<div><span class="text-danger">*</span> means Mandatory.</div>
	<div align="right">
	<input type="hidden" name="action" value="<?=$action?>exe">
	<input type="hidden" name="id" value="<?=isset($_REQUEST['id'])?$_REQUEST['id']:''?>">
	<button type="button" class="btn btn-danger" onClick="window.location='index.php?goto=<?=$_GET['goto']?>'"> <i class="glyphicon glyphicon-open"></i> Cancel</button>  <button type="submit" class="btn btn-primary pull-right" style="margin-left:4px;"> <i class="glyphicon glyphicon-save"></i> Save</button> </div>
	</form>
	
	<div align="center">
	<a href="index.php?goto=<?=$_GET['goto']?>">Back To List</a>
	</div>
	<?	
	break;
	
	default:

	
	
	$cn=mysqli_query($link_connect,"select * from users ".$qry." order by id asc");
	?>
	<? if (isset($msgerr)&& $msgerr) {?>
	<div role="alert" class="alert alert-danger"><?=$msgerr?></div>
	<? }?>
	<? if (isset($msgsuccess) && $msgsuccess) {?>
	<div role="alert" class="alert alert-success"><?=$msgsuccess?></div>
	<? }?>
	<form action="index.php?goto=<?=$_GET['goto']?>" method="post" name="del">
	<div id="toolbar" class="btn-group noprint">
	 <? if($_SESSION["admin_role"]=="SuperAdmin") { ?> <button type="button" class="btn btn-primary" onclick="window.location='index.php?goto=<?=$_GET['goto']?>&action=add'">
			<i class="glyphicon glyphicon-plus"></i> Add
		</button>
		<button type="button" class="btn btn-primary" onclick="conf()">
			<i class="glyphicon glyphicon-trash"></i> Delete
		</button><? } ?><button type="button" class="btn btn-success" onclick="window.location='pages/export_csv.php?table=scheduling&filename=<?=$_GET['goto']?>'">
        <i class="glyphicon glyphicon-export"></i> Export
    </button><button type="button" class="btn btn-success" onclick="window.print();">
        <i class="glyphicon glyphicon-print"></i> Print
    </button>
	</div>
	<table data-toggle="table" data-escape="false"  
    data-classes="table table-hover table-condensed"
	data-striped="true"
	data-cache="false"
	data-search="true"
	 data-show-refresh="true"
	data-show-toggle="true"
	data-show-columns="true"
	data-toolbar="#toolbar"
	data-pagination="true"
    data-page-list="[10,25,50,100,All]"
    data-page-size="25"	
    data-show-export="true"
    data-export-types="['csv', 'txt', 'excel']"data-state-save="true"
	data-state-save-id-table="users" 	
	data-sort-name="id"
	data-sort-order="asc"	
	>
	<thead>
	 <? if($_SESSION["admin_role"]=="SuperAdmin") { ?> <th><i class="glyphicon glyphicon-remove"></i></th>
			<? } ?><th data-visible="false"  data-sortable="true"  data-field="id" data-halign="center"  data-align="left">ID</th>
		<th  data-sortable="true"  data-field="name" data-halign="center"  data-align="left">Name</th>
		<th>Action</th>
		
	</thead><tbody>
	<? while ($rs=mysqli_fetch_object($cn)) {?>
	<tr <? if (isset($_REQUEST['id']) && $rs->id==$_REQUEST['id']) {?> class="success" <? }?>>
		 <? if($_SESSION["admin_role"]=="SuperAdmin") { ?> <td><input type="checkbox" name="ids[]" value="<?=$rs->id?>"></td>
			<? } ?><td><?=$rs->id?></td>
				<td dir="ltr"><?=$rs->name?></td>
				<td><a href="index.php?goto=<?=$_GET['goto']?>&id=<?=$rs->id?>&action=edit" title="Edit"><i class="glyphicon glyphicon-edit"></i></a> </td>
		</tr>
		
	<? } ?>
	</tbody>
	</table> <? if($_SESSION["admin_role"]=="SuperAdmin") {?> 
	<input type=hidden name="action" value="delete"><? } ?></form>
	 <? if($_SESSION["admin_role"]=="SuperAdmin") {?> 	
	<script language="javascript">
	function conf(){
		if (confirm("Are you sure you want to delete this/these record(s)?")) {
			document.forms["del"].submit(); 
		}
	}
	</script><? } ?>
	<? endswitch; ?>