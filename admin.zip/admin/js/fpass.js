$(document).ready(function(){
$('#submit').click(function() {

$('#fpwaiting').show(0);
$('#fpassf').hide(0);
$('#fpmessage').hide(0);

$.ajax({
type : 'POST',
url : 'ajaxpost/fpass.php',
dataType : 'json',
data: {
fpemail : $('#fpemail').val()
},
success : function(data){
$('#fpassf').show(0);
$('#fpwaiting').hide(0);
$('#fpmessage').removeClass().addClass((data.error === true) ? 'alert alert-danger' : 'alert alert-success')
.text(data.msg).show(0);

},
error : function(XMLHttpRequest, textStatus, errorThrown) {
$('#fpwaiting').hide(0);
$('#fpmessage').removeClass().addClass('alert alert-danger')
.text('Oops! Something went Terribly Wrong, please Try Again.').show(0);
$('#fpassf').show(0);
}
});

return false;
});
});