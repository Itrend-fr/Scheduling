// JavaScript Document
$(document).ready(function(){
$('#resetsubmit').click(function() {
	
$('#resetform').hide(0);
$('#rswaiting').show(0);
$('#rsmessage').hide(0);

$.ajax({
type : 'POST',
url : 'ajaxpost/reset.php',
dataType : 'json',
data: {
password : $('#password').val(),
retypepassword : $('#retypepassword').val(),
t : $('#t').val(),
i : $('#i').val(),
d : $('#d').val(),

},
success : function(data){
		$('#rswaiting').hide(0);
	if (data.error == false) {
		$('#rsmessage').removeClass().addClass('alert alert-success').html(data.msg).show(0);
		$('#resetform').hide(0);
	} else if (data.error === true) {
		$('#rsmessage').removeClass().addClass('alert alert-danger').html(data.msg).show(0);
		$('#resetform').show(0);
	}
},
error : function(XMLHttpRequest, textStatus, errorThrown) {
	$('#rswaiting').hide(0);
	$('#rsmessage').removeClass().addClass('alert alert-danger').html('Oops! Something went Terribly Wrong, please Try Again.').show(0);
	$('#resetform').show(0);
}
});

return false;
});
});