$(document).ready(function(){
$('#loginsubmit').click(function() {

$('#loginwaiting').show(0);
$('#loginform').hide(0);
$('#loginmessage').hide(0);
$('#forgotpass').hide(0);

$.ajax({
type : 'POST',
url : 'ajaxpost/login.php',
dataType : 'json',
data: {
email : $('#email').val(),
password : $('#password').val()
},
success : function(data){
if (data.error == false) {
window.location.href=data.link;
} else if (data.error === true) {
$('#loginmessage').removeClass().addClass('alert alert-danger')
.text(data.msg).show(0);
$('#loginwaiting').hide(0);
$('#loginform').show(0);
}
},
error : function(XMLHttpRequest, textStatus, errorThrown) {
$('#loginwaiting').hide(0);
$('#loginmessage').removeClass().addClass('alert alert-danger')
.text('Oops! Something went Terribly Wrong, please Try Again.').show(0);
$('#loginform').show(0);
}
});

return false;
});
});