<style>

a {
	color:<?=$primary_color?>;	
}

a:hover, a:focus {
	color:<?=$secondary_color?>;	
}

.btn-primary {
	background-color:<?=$primary_color?>;
	border-color:<?=$primary_color?>;
}

.btn-primary:hover,.btn-primary:focus,.btn-primary.focus,.btn-primary:active,.btn-primary.active {
	background-color:<?=$secondary_color?>;
	border-color:<?=$secondary_color?>;	
}

.btn-inverse {
	background-color:<?=$secondary_color?>;
	border-color:<?=$secondary_color?>;		
	color:#FFF;
}

.btn-inverse:hover,.btn-inverse:focus,.btn-inverse.focus,.btn-inverse:active,.btn-inverse.active {
	background-color:<?=$primary_color?>;
	border-color:<?=$primary_color?>;
	color:#FFF;
}

.btn-link {
	color:<?=$primary_color?>;
}

.btn-link:hover,.btn-link:focus {
	color:<?=$secondary_color?>;
}

.nav-sidebar > .active > a, .nav-sidebar > .active > a:hover, .nav-sidebar > .active > a:focus {
	background-color:<?=$primary_color?>;
}

.pagination > li > a, .pagination > li > span {
	color:<?=$primary_color?>;
}

.pagination > li > a:hover {
	color:<?=$secondary_color?>;
}

.pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {
	background-color:<?=$primary_color?> !important;	
	border-color:<?=$primary_color?> !important;	
}

.dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
		background-color:<?=$primary_color?>;
}

 .form-control:focus {
    border-color:<?=$secondary_color?>;
    outline: 0px none;
    box-shadow:none;
}


</style>