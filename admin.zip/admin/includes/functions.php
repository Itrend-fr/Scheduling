<?


function date_disp($format, $date) {
	return date($format,strtotime($date)); 
}

## Localization function
function loc($id,$strip='') {
	if ($_SESSION['langue']) { $lang=$_SESSION['langue']; } else { $lang=$_SESSION['lang']; }
	$return= getfield("fe_localization",$lang," where id='".Q($id)."'");
	if ($strip) { return strip_tags($return); } else { return str_replace('../',BURL,$return); }
}

		
		
## checking sections level
function check_position($thepos,$level=0) {
				$prevpos=getfield("fe_sections","position"," where id='".Q($thepos)."'");
				if (is_numeric($prevpos)) {
					$level+=1;
					check_position($prevpos,$level);
				} else {
					echo $level.'|'.$prevpos;
				}		
}


# construction section rewrite link
function sec_rw($id,$url=array(),$reverse='') {
		if(!$url) $url = array();
		$url[]=getfield("fe_sections","name_rw"," where id='".Q($id)."'");
		
		if ($reverse) {
			$newid=getfield("fe_sections","id"," where position='".Q($id)."' order by pos asc");
		} else {
			$newid=getfield("fe_sections","position"," where id='".Q($id)."'");
		}
		
		if (is_numeric($newid)) {
			$url[]= sec_rw($newid,$url,$reverse);
		} else {
			if (!$reverse) { $url=array_reverse($url); }
			echo implode("/",$url);	
		}
}


# constructing extension menu
function menuext($filter_name,$filter_value) {	
	$filter_name=explode("|",$filter_name);
	$filter_value=explode("|",$filter_value);
	$menuext=array();
	$i=0;
	foreach($filter_name as $value) {
		$menuext[]=$value.'='.	$filter_value[$i];
		$i++;
	}
	$menuext=implode("&",$menuext);
	return $menuext;
}

# check at least one SuperAdmin or one Admin
function checkadmin($id,$type,$action) {
	global $link_connect;
	if (is_numeric($id) && $action='editexe') {
		$cn=mysqli_query($link_connect,"select type from bo_admins where id='".Q($id)."'");
		$rs=mysqli_fetch_object($cn);
		if ($rs->type!=$type && $rs->type!='User') {
			
			$cni=mysqli_query($link_connect,"select * from bo_admins where id!='".Q($id)."' and type='".Q($rs->type)."'");
			if (!mysqli_num_rows($cni)) {
				return false;
			} else {
				return true;	
			}
		} else {
			return true;	
		}

	} else {
		return true;	
	}
}


// is date
function validateDate($date, $format = 'Y-m-d H:i:s')
{
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) == $date;
}

// is phone
function validatePhone($phone) {
	if (is_numeric($phone) && strlen($phone)>=10 && substr($phone, 0, 1)!=0) {
		return true;
	} else {
		return false;	
	}
}

// is email
function isemail($strng){ 
return preg_match('/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/i',$strng);
}

// is numeric
function validateNumeric($number) {
	if (is_numeric($number)) {
		return true;
	} else {
		return false;
	}
}

// is password
function validatePassword($password) {
	if (strlen($password)>=8 && strlen($password)<=16) {
		return true;
	} else {
		return false;	
	}
}

function getip(){

	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {

    	$ip = $_SERVER['HTTP_CLIENT_IP'];

	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {

		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

	} else {

		$ip = $_SERVER['REMOTE_ADDR'];

	}

	return $ip;

}

function validaeUsername($username){
	if(count(explode(' ',$username))>1){
		return false;
	}
	if(preg_match('/^[a-zA-Z0-9]{5,}$/', $username)) { // for english chars + numbers only
		return true;
	}
	return true;
}

// check if Section has sub section in BO Interface
function checksubbo($id) {
	global $link_connect;
$cn=mysqli_query($link_connect,"select id from bo_interface where boid ='".Q($id)."'");
if (mysqli_num_rows($cn)) {
return true;	
}
}

// is url
function validateURL($URL) {     
$v = "/^(http|https|ftp|sftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i";     
return (bool)preg_match($v, $URL);
}

// return single value

function getfield($tbl,$field,$qry) {
	global $link_connect;
	$qrs = "select ".$field." from ".$tbl." ".$qry;
	$cn=mysqli_query($link_connect,$qrs) or die(mysqli_error($link_connect));
	if (mysqli_num_rows($cn)) {
		$rs=mysqli_fetch_array($cn);
		$fieldar=explode(",",$field);
		if(count($fieldar)>1) {
			foreach($fieldar as $value) {
			$rsfield[$value]=$rs[$value];
			}
			return $rsfield;
		} else {
		return $rs[$field];
		#return mysqli_num_rows($cn);	
		}
	}
	#return $qrs;
}


function html2txt($text){
	$search = array('@<script[^>]*?>.*?</script>@si', // Strip out javascript
	'@<style[^>]*?>.*?</style>@siU', // Strip style tags properly
	'@<[?]php[^>].*?[?]>@si', //scripts php
	'@<[?][^>].*?[?]>@si', //scripts php
	'@<[\/\!]*?[^<>]*?>@si', // Strip out HTML tags
	'@<![\s\S]*?--[ \t\n\r]*>@' // Strip multi-line comments including CDATA
	);
	$text = preg_replace('#<br\s*/?>#i', "[BR]", $text);
	$text = preg_replace('#</tr>#i', "[BR]", $text);
	$text = preg_replace('#</div>#i', "[BR]", $text);
	$text = preg_replace('#</p>#i', "[BR][BR]", $text);
	$text=preg_replace('/<img(.*?)alt="(.*?)"(.*?)>/', "$2", $text);
	$text=preg_replace('/<a(.*?)href="(.*?)"(.*?)>/', "$2 ", $text);
	$text = str_replace('&nbsp;'," ", $text);
	$text = preg_replace($search, '', $text);
	$text=preg_replace('!\s+!', ' ',$text);
	$text = preg_replace('/\[BR\]/', "\n", $text);
	$text = str_replace('mailto:'," ", $text);
	return $text;
}


function encrypt($sData, $sKey){
$sResult = '';
for($i=0;$i<strlen($sData);$i++){
$sChar    = substr($sData, $i, 1);
$sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1);
$sChar    = chr(ord($sChar) + ord($sKeyChar));
$sResult .= $sChar;
}
return encode_base64($sResult);
}

function decrypt($sData, $sKey){
$sResult = '';
$sData   = decode_base64($sData);
for($i=0;$i<strlen($sData);$i++){
$sChar    = substr($sData, $i, 1);
$sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1);
$sChar    = chr(ord($sChar) - ord($sKeyChar));
$sResult .= $sChar;
}
return $sResult;
} 

function strip($str,$numchar){
	$p=substr($str, 0, 3);
	$endp=substr($str, -4); 
		if($p=="<p>" && $endp=="</p>")
			$str=substr($str,3,strlen($str)-7);
			$str=strip_tags($str);
		if(strlen($str) > $numchar){ 
			$position=strrpos(substr($str,0,$numchar)," ");
			$str=substr($str,0,$position);
			$str=html_entity_decode($str, ENT_COMPAT, 'UTF-8')." ...";
		}
	return $str;
}

function Q($q) {
	global $link_connect;
	return mysqli_real_escape_string($link_connect, $q);
}

function trime($strng){ 
	return stripslashes(trim($strng)); 
}

function textencode($strng) { 
	return htmlspecialchars($strng);
}

?>