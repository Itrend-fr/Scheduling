<?
#error_reporting (E_ALL ^ E_NOTICE);
## Site Debug ##
$debug=1; // Set 0 to turn off, 1 to turn on

## DB Connection ##
$whitelist = array('127.0.0.1', "::1");

if(in_array($_SERVER["REMOTE_ADDR"], $whitelist)){
    # local
	$link_connect=mysqli_connect("localhost", "root", ""); 
	mysqli_select_db($link_connect,"scheduling");
	
	# local Directory Path
	
	# Site URL on Local
	$site_url='http://localhost/doctolib.com/html/'; ## with / at the end
	
} else {
	
}

mysqli_query($link_connect,"SET NAMES 'utf8'");
mysqli_query($link_connect,'SET CHARACTER SET utf8'); 



## Session Name ##
$sessobject_name='scheduling';

## Site Info ##
$bo_sitename='Schedling';
$site_logo='nlogo.png'; // stored in images folder
$site_favicon=$site_url.'favicon.png';
$primary_color='#a9a9a9';
$secondary_color='#000000';

define("BURL",$site_url);

date_default_timezone_set('Asia/Beirut'); 
?>